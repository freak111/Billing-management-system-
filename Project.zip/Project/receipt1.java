import javax.swing.*;
import java.awt.*;
import java.applet.*;
public class receipt1 extends JFrame
{
JPanel p1;
JLabel l1,l2,l3,l4,l5,l6;
JButton b1;
JTextArea t1,t2,t3,t4,t5,t6;
ImageIcon i;
public receipt1(String s1, String s2, String s3)
{
Color c=new Color(62,159,94);
Color c1=new Color(255,255,255);
Font f1=new Font("Lucida Calligraphy",Font.BOLD|Font.ITALIC,17);
Font f2= new Font("Times New Roman",Font.BOLD,17);
getContentPane().setBackground(c);
setLayout(null);
p1=new JPanel();
add(p1);
p1.setBounds(440,120,500,500);
p1.setLayout(null);

l1=new JLabel("BILL AMOUNT IN RUPESS:");
l2=new JLabel("INVOICE NO:");
l4=new JLabel("DATE OF PAYMENT :");
l5=new JLabel("RECIEPT");

p1.add(l1);
p1.add(l2);
//p1.add(l3);
p1.add(l4);
p1.add(l5);

l1.setBounds(30,50,200,30);
l2.setBounds(30,120,200,30);
l3.setBounds(30,190,200,30);
l4.setBounds(30,260,200,30);
l5.setBounds(30,340,200,30);
l6.setBounds(30,410,200,30);

l1.setFont(f2);
l2.setFont(f2);
l3.setFont(f2);
l4.setFont(f2);
l5.setFont(f2);
l6.setFont(f2);

t1=new JTextArea();
t2=new JTextArea();
t3=new JTextArea();
t4=new JTextArea();
t5=new JTextArea();

p1.add(t1);
p1.add(t2);
p1.add(t3);
p1.add(t4);
p1.add(t5);
p1.add(t6);

t1.setBounds(210,50,200,30);
t2.setBounds(210,120,200,30);
t3.setBounds(210,190,200,30);
t4.setBounds(210,260,200,30);
t5.setBounds(210,340,200,30);

t1.setEditable(false);
t2.setEditable(false);
t3.setEditable(false);
t4.setEditable(false);
t5.setEditable(false);
t1.setText(s1);
t2.setText(s2);
t3.setText(s3);

}
}