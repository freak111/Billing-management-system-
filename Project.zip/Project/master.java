import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.io.IOException;
public class master extends JFrame implements ActionListener
{
JButton b,b1,b2;
JTextField t,t1,t2,t14,t4,t5;
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public master()
{
Container c=getContentPane();
setLayout(null); 
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k6.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,600,1500,90);
Color j11=new Color(130,21,11,141);
to.setBackground(j11);
Font ts=new Font("Agency FB",Font.BOLD,20);
k.setFont(ts);k2.setFont(ts);
k1.setFont(ts);k7.setFont(ts);
k3.setFont(ts);k4.setFont(ts);k6.setFont(ts);
Color j1=new Color(230,21,131,141);
k.setForeground(j1);
k1.setForeground(j1);
k3.setForeground(j1);
k4.setForeground(j1);
k2.setForeground(j1);k6.setForeground(j1);
k7.setForeground(j1);




Font e=new Font("Nyala",Font.BOLD,20);
//Font ts=new Font("Aparajita",Font.BOLD,18);
Font ts1=new Font("Aparajita",Font.BOLD,14);
JLabel l=new JLabel("MASTER FORM",Label.LEFT);
JLabel l1=new JLabel("Rental Code");
JLabel l2=new JLabel("Local call rates");
JLabel l3=new JLabel("ISD call rates");
JLabel l4=new JLabel("STD call rates");
//JLabel l5=new JLabel("Free Calls");
JLabel l6=new JLabel("Plan Cost");
t1=new JTextField();
 t=new JTextField();
 t2=new JTextField();

 t14=new JTextField();
 t4=new JTextField();
t5=new JTextField();
Icon h=new ImageIcon("confirm.jpg");
 b=new JButton(h);
b.addActionListener(this);

 b2=new JButton("New rental Plan");
b2.addActionListener(this);
Icon hl=new ImageIcon("cancel.jpg");
 b1=new JButton(hl);
b1.addActionListener(this);

l.setBounds(300,200,180,30);
l1.setBounds(20,250,120,30);
l2.setBounds(20,300,220,30);
l3.setBounds(20,350,120,30);
l4.setBounds(20,450,300,30);

//l5.setBounds(20,450,220,30);
l6.setBounds(20,400,120,30);
t.setBounds(250,250,300,20);
t1.setBounds(250,300,300,20);
t2.setBounds(250,350,300,20);

t14.setBounds(250,400,300,20);
//t4.setBounds(250,450,300,20);
t5.setBounds(250,450,300,20);
b.setBounds(80,550,176,30);
b1.setBounds(270,550,176,30);
b2.setBounds(500,550,200,30);
add(b2);
//b2.setBounds(470,650,180,30);
//b3.setBounds(700,650,180,30);
add(l);
add(l1);
add(l2);
add(l3);
add(l4);
//add(l5);
add(l6);
add(t);
add(t1);
add(t2);
add(t4);
add(t5);
add(b);
add(b1);
add(t14);
//add(b2);
//add(b3);

l.setFont(e);
l1.setFont(ts);
l2.setFont(ts);
l3.setFont(ts);
l4.setFont(ts);
//l5.setFont(ts);
l6.setFont(ts);

l.setForeground(Color.blue);
l1.setForeground(Color.red);
l2.setForeground(Color.red);
l3.setForeground(Color.red);
l4.setForeground(Color.red);
//l5.setForeground(Color.red);
l6.setForeground(Color.red);

Icon i=new ImageIcon("furn_TEL.gif");
JLabel s1=new JLabel(i);
s1.setBounds(890,180,160,260);
add(s1);


Icon i3=new ImageIcon("ban3.jpg");
JLabel e1=new JLabel(i3);
e1.setBounds(0,0,1343,186);
add(e1);

}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b2)
{
try
{
long a=110;
int row=0;
ResultSet y3;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
y3=x.executeQuery("select * from master");
while(y3.next())
{
row=row+1;
}
if(row==0)
{
String x46= new Long(a).toString();
t.setText(x46);
}
else
{
long d=a+row;
String x46= new Long(d).toString();
t.setText(x46);
}
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}





}
if(e.getSource()==b1)
{
t1.setText("");
t.setText("");t2.setText("");t4.setText("");t5.setText("");t14.setText("");
}
if(e.getSource()==k)
{
sub dw1=new sub();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k4)
{
query1 dw1=new query1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k6)
{
piz1 dw1=new piz1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==b)
{
String str,str1,str2,str3,str4,str5;
{
try
{
str=t.getText();
str1=t1.getText();
str2=t2.getText();
//str3=t4.getText();
str4=t14.getText();
str5=t5.getText();





//String d=c1.getSelectedItem().toString();
//System.out.println(d);
//System.out.println(coun);
//String d1=c2.getSelectedItem().toString();
//System.out.println(d1);
//String d2=c3.getSelectedItem().toString();
//System.out.println(d2);
//Boolean r21=b1.isSelected();
//StringBuffer buffer = new StringBuffer(); 
//buffer.append(d).append("/").append(d1).append("/").append(d2); 
//String result = buffer.toString();
/*System.out.println(r21);
String gen;
if(r21==true)
{
 gen="resi";
}
else 
{
 gen="buisness";
}*/
ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into master values(' "+ str +" ', '"+ str1 +"','"+ str2 +"','"+ str4 +"', '"+ str5 +"' )");
System.out.println("inserted records ");
JOptionPane.showMessageDialog(null,"Data is successfully submitted into database.");
y1=x.executeQuery("select * from master");
while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2)+"\t" + y1.getString(3)+"\t" + y1.getString(4)+"\t" + y1.getString(5)+"\t");
co.close();
}
catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"Data cannot be inserted into database.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
}
}
}


public static void main(String ad[])
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dw1.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}
