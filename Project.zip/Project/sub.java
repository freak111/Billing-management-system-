import java.sql.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.util.*;
import java.awt.*;
import java.io.IOException;
public class sub extends JFrame implements ActionListener
{
Font tr=new Font("Forte",Font.BOLD,18);
JButton k=new JButton("METER",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("COMPLAIN",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
JButton k8=new JButton("LOGOUT",new ImageIcon("dfat.jpg"));
public sub()
{
Container c=getContentPane();
setLayout(null);
Icon i4=new ImageIcon("ban4.jpg");
JLabel e14=new JLabel(i4);
e14.setBounds(0,0,1343,186);
add(e14);
Icon i24=new ImageIcon("ban10.jpg");
JLabel e24=new JLabel(i24);                         
e24.setBounds(10,250,616,415);
add(e24);
Icon i40=new ImageIcon("hawk-critic-468x60 - Copy.gif");
JLabel e140=new JLabel(i40);
e140.setBounds(660,240,468,60);
add(e140);
Icon i4q=new ImageIcon("mob1.jpg");
JLabel e4q=new JLabel(i4q);
e4q.setBounds(660,440,151,215);
//add(e4q);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k6.addActionListener(this);
k7.addActionListener(this);
k8.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
to.addSeparator();
to.add(k8);
add(to,BorderLayout.SOUTH);
to.setBounds(0,170,1500,70);
Color j11=new Color(60,60,111,130);
to.setBackground(j11);
Color l11=new Color(160,70,11,30);
c.setBackground(l11);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
meter dw1=new meter();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k4)
{
query1 dw1=new query1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k6)
{
piz1 dw1=new piz1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k7)
{
aboutus dw1=new aboutus();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k8)
{
 login121 dw1=new login121();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
}

public static void main(String af[])
{
sub s=new sub();
s.setVisible(true);
s.setBounds(0,0,1200,700);
s.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}