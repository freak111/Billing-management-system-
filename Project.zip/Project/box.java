import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
public class box extends JApplet
{
public void init()
{
setLayout(null);
Container c=getContentPane();
JPanel l3=new JPanel();

c.setBackground(Color.pink);

l3.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Billing"));
l3.setLayout(new BoxLayout(l3, BoxLayout.Y_AXIS));
l3.add(Box.createVerticalStrut(45));
l3.add(new JLabel("Enter the no"));
l3.add(Box.createVerticalStrut(45));
l3.add(new JLabel("Enter the no"));
l3.add(Box.createVerticalStrut(145));
l3.add(new JLabel("Enter the no"));
l3.add(Box.createVerticalStrut(145));
c.add(l3);
l3.setBackground(Color.green);

setLayout(new FlowLayout());
JPanel l2=new JPanel();
l2.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Billing"));
l2.setLayout(new BoxLayout(l2, BoxLayout.Y_AXIS));
l2.add(Box.createVerticalStrut(30));
l2.add(Box.createGlue());
l2.add(new JRadioButton("PrePaid"));
l2.add(Box.createVerticalStrut(30));
l2.add(new JTextField(20));
l2.add(Box.createVerticalStrut(30));
l2.add(new JTextField(20));
l2.add(Box.createVerticalStrut(30));
c.add(l2);
l2.setBackground(Color.red);

JScrollPane js=new JScrollPane(l3,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
c.add(js);
JScrollPane jy=new JScrollPane(l2,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);c.add(jy);
}

}
/*<applet code="box" height=666 width=666>
</applet>*/