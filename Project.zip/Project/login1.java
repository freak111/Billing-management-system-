import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import javax.swing.*;

public class login1 extends Applet implements ActionListener
{
Panel p1,p2;
Label l1,l2,l3;
TextField t1,t2;
Button b1,b2;
Image i;

public void init()
{
        setLayout(null);
   /*      bar one = new bar();
	one.setBounds(0,0,1000,100);
	one.setVisible(true);
        one.setBackground(Color.red);
        Panel p3=new Panel();
        p3.setLayout(null);
        p3.setBounds(180,80,1000,500);
	p3.add(one);
        add(p3);     */
 l1=new Label("USER NAME",Label.CENTER);
      add(l1);
      t1=new TextField(20);
      add(t1);
      l2=new Label("PASSWORD",Label.CENTER);
      add(l2);
      t2=new TextField(20);
      add(t2);
      t2.setEchoChar('*');
     Icon hl=new ImageIcon("ram.jpg");
JButton b12=new JButton(hl);
add(b12);

b12.setRolloverEnabled(true);
     Icon h=new ImageIcon("Untitled.jpg");
JButton b2=new JButton(h);
add(b2);

b12.setRolloverEnabled(true);
        Font rte=new Font("Aparajita",Font.BOLD,20);
l1.setFont(rte);
l2.setFont(rte);       
      b1.addActionListener(this);
      l1.setBounds(850,250,80,30);
      l2.setBounds(850,300,80,30);
      t1.setBounds(950,250,200,30);
      t2.setBounds(950,300,200,30);
      b12.setBounds(900,350,60,30);
      b2.setBounds(1000,350,70,30);

    l3=new Label("Welcome To Wild Life Safari Trip                                                                                   ");   
    l3.setBounds(0,0,2000,100);
    Font f1= new Font("Segoe Print",Font.BOLD|Font.ITALIC,40);
    l3.setFont(f1);
    Color x=new Color(37,124,35);
    Color y=new Color(255,255,255);
    l3.setForeground(y);
    l3.setBackground(x);
    add(l3, BorderLayout.NORTH);
    javax.swing.Timer timer = new javax.swing.Timer(100, this);
    timer.start();

t1.addActionListener(this);
t2.addActionListener(this);
b1.addActionListener(this);
}
   
public void paint(Graphics g)
  {
      i = getImage(getDocumentBase(),"lion.jpg");
      g.drawImage(i, 0, 0, getWidth(), getHeight(), this);
  }
public void actionPerformed(ActionEvent e)
{
    String oldText = l3.getText();
    String newText = oldText.substring(1) + oldText.substring(0, 1);
    l3.setText( newText );  

if(e.getSource()==b1)
{
String r,r1;
r=t1.getText();
int u=r.length();
r1=t2.getText();
int p=r1.length();
if(u==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
else if(p==0)
{
JOptionPane.showConfirmDialog((Component)null,"Enter Password","Error",JOptionPane.OK_CANCEL_OPTION);  
}
else if(p>8)
{
JOptionPane.showConfirmDialog((Component)null,"Cannot Exceed More Than 8 Character","Error",JOptionPane.OK_CANCEL_OPTION);
//d=JOptionPane.ERROR_MESSAGE;
}
newlog objt = new newlog();
setVisible(false);
setSize(0,0);
objt.setSize(2000,1000);
objt.setVisible(true);
}
}
}



/*
<applet code="login1" height=500 width=500 >
</applet>*/