import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
public class piz11 extends JFrame implements ActionListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("TRANSECTION",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public piz11()
{
Container c=getContentPane();
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,600,1500,90);
Color j11=new Color(170,11,111,41);
to.setBackground(j11);


ButtonGroup be=new ButtonGroup();
setLayout(null);
JRadioButton b1=new JRadioButton("PrePaid");
add(b1);
be.add(b1);
JRadioButton b2=new JRadioButton("PostPaid");
add(b2);
be.add(b2);
JRadioButton b3=new JRadioButton("GSM Services");
add(b3);
be.add(b3);
JRadioButton b4=new JRadioButton("GPRS Services");
add(b4);
be.add(b4);
JRadioButton b5=new JRadioButton("Roaming");
add(b5);
be.add(b5);
b1.setBounds(100,320,300,40);
b2.setBounds(100,350,300,40);
b3.setBounds(100,380,300,40);
b4.setBounds(100,410,300,40);
b5.setBounds(100,440,300,40);
Icon i=new ImageIcon("148672140.jpg");
JLabel s1=new JLabel(i);
s1.setBounds(690,350,120,200);
add(s1);
Font rte=new Font("Copperplate Gothic Light",Font.BOLD,20);
b1.setFont(rte);
b2.setFont(rte);
b3.setFont(rte);
b4.setFont(rte);
b5.setFont(rte);
b5.setForeground(Color.red);
b4.setForeground(Color.red);
b1.setForeground(Color.red);
b2.setForeground(Color.red);
b3.setForeground(Color.red);

Color j=new Color(30,211,13,14);
c.setBackground(j);
Icon i4=new ImageIcon("ban4.jpg");
JLabel e14=new JLabel(i4);
e14.setBounds(0,0,1343,186);
add(e14);
Font topr=new Font("Forte",Font.BOLD,25);
JLabel rb=new JLabel("MOBILE");
rb.setBounds(280,210,360,30);
rb.setForeground(Color.blue);
add(rb);
rb.setFont(topr);

Icon h=new ImageIcon("confirm.jpg");
JButton b=new JButton(h);
Icon hl=new ImageIcon("cancel.jpg");
JButton b1q=new JButton(hl);
Icon h2=new ImageIcon("reset.jpg");
JButton b2q=new JButton(h2);

b.setBounds(80,500,180,30);
b1q.setBounds(270,500,180,30);
b2q.setBounds(470,500,180,30);
add(b);
add(b1q);
add(b2q);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
login121 obj2 = new login121();
obj2.setVisible(true);
obj2.setSize(1000,600);
}
}
public static void main(String ad[])
{
piz11 dw1=new piz11();
dw1.setBounds(200,200,400,400);
dw1.setVisible(true);
}
}
/*<applet code="piz1" height=555 width=555>
</applet>*/