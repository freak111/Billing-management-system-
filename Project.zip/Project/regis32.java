import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.io.IOException;
public class regis32 extends JFrame implements ActionListener 
{
JPanel z1,z2;
JButton bk,zx,b2k,b1k;
JTextField t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t110,t111,t112,t11r,t1r;
JComboBox m,m1,pr,m2;
JRadioButton b1,b2,b3,b4,b121,b12,b13,b14,b21,bw;
public regis32()
{

Container c=getContentPane();
setLayout(null);
JButton y,y1,b11;
Icon hi=new ImageIcon("bkdkcopy.jpg");
 y=new JButton(hi);
y.setBounds(50,100,120,60);
//add(y);
Icon h=new ImageIcon("bkdk1.jpg");
 y1=new JButton(h);
y1.setBounds(190,100,120,60);
//add(y1);
 zx=new JButton("New");
zx.setBounds(70,100,120,60);
add(zx);
zx.addActionListener(this);
Color r=new Color(137,10,19,114);
c.setBackground(r);
Icon i=new ImageIcon("user6copy.jpg");
JLabel s1=new JLabel(i);
add(s1);
s1.setBounds(100,0,1004,87);
Icon i3=new ImageIcon("line.jpg");
JLabel l4=new JLabel(i3);
add(l4);
l4.setBounds(5,160,1335,10);
Icon i4=new ImageIcon("line.jpg");
JLabel l5=new JLabel(i4);
add(l5);
l5.setBounds(5,90,1335,20);
JLabel l28=new JLabel("Customer ID");
add(l28);
l28.setBounds(10,190,171,20);
JLabel l8=new JLabel("Name of Customer");
add(l8);
l8.setBounds(10,230,171,20);
JLabel l11=new JLabel("Name of Joint Appleication");
add(l11);
l11.setBounds(10,270,171,20);
JLabel l12=new JLabel("Name of Father/Husband");
add(l12);
l12.setBounds(10,310,171,20);
JLabel l13=new JLabel("PAN Card No.");
add(l13);
l13.setBounds(10,350,171,20);
JLabel l14=new JLabel("No of Telephone Connection Required");
add(l14);
l14.setBounds(10,390,231,20);
JLabel l15=new JLabel("Complete Address Where Telephone is Required");
add(l15);
l15.setBounds(65,410,281,20);
JLabel l16=new JLabel("House No.");
add(l16);
l16.setBounds(10,450,100,20);
JLabel l17=new JLabel("Street");
add(l17);
l17.setBounds(355,450,100,20);
JLabel l18=new JLabel("Appartment/Building");
add(l18);
l18.setBounds(10,490,140,20);
JLabel l19=new JLabel("Area");
add(l19);
l19.setBounds(355,490,100,20);
JLabel l20=new JLabel("City");
add(l20);
l20.setBounds(10,530,50,20);
JLabel l21=new JLabel("State");
add(l21);
l21.setBounds(345,530,50,20);
JLabel l22=new JLabel("Email ID");
add(l22);
l22.setBounds(650,190,50,20);
Icon hq=new ImageIcon("line2.jpg");
JLabel y1q=new JLabel(hq);
y1q.setBounds(620,165,10,600);
add(y1q);

t8= new JTextField(20);
add(t8);
t8.setBounds(235,230,200,20);
 t9= new JTextField(20);
add(t9);
t9.setBounds(235,270,200,20);
 t10= new JTextField(20);
add(t10);
t10.setBounds(235,310,200,20);
t11= new JTextField(20);
add(t11);
t11.setBounds(235,350,200,20);
t12= new JTextField(20);
add(t12);
t12.setBounds(275,390,130,20);
t13= new JTextField(20);
add(t13);
t13.setBounds(80,455,270,20);
t14= new JTextField(20);
add(t14);
t14.setBounds(400,455,170,20);
t15= new JTextField(20);
add(t15);
t15.setBounds(130,495,170,20);
t16= new JTextField(20);
add(t16);
t16.setBounds(400,495,170,20);
t17= new JTextField(20);
add(t17);
t17.setBounds(780,190,250,20);
t18= new JTextField(20);
add(t18);
t18.setBounds(235,190,200,20);
m=new JComboBox();
m.addItem("CITY");m.addItem("AGRA");m.addItem("ALLAHABAD");
m.addItem("BANGLORU");m.addItem("DELHI");m.addItem("GUJRAT");
m.addItem("MUMBAI");m.addItem("LUCKNOW");m.addItem("CHENNAI");m.addItem("BARELI");
m.addItem("AHAMDABAD");m.addItem("BHOPAL");m.addItem("KANPUR");m.addItem("MADRAS");
add(m);
m.setBounds(70,530,170,20);
m1=new JComboBox();
m1.addItem("UTTAR PARADESH");m1.addItem("MAHARASTRA");m1.addItem("ANDHRA PARADESH");
m1.addItem("RAJISTHAN");m1.addItem("UTTRAKHAND");m1.addItem("GUJRAT");
m1.addItem("TAMILNADU");m1.addItem("MADRAS");
m1.setBounds(390,530,170,20);
add(m1);


JLabel l128=new JLabel("PURPOSE");
add(l128);
l128.setBounds(835,220,171,20);
ButtonGroup be=new ButtonGroup();
b1=new JRadioButton("Residental");
add(b1);
be.add(b1);
 b2=new JRadioButton("Business");
add(b2);
be.add(b2);
 b3=new JRadioButton("Government");
add(b3);
be.add(b3);
b4=new JRadioButton("Public Sector Unit");
add(b4);
be.add(b4);
b1.setBounds(680,250,100,30);
b2.setBounds(780,250,100,30);
b3.setBounds(880,250,100,30);
b4.setBounds(980,250,200,30);
JLabel lv=new JLabel("FACILITY");
add(lv);
lv.setBounds(835,280,171,20);
ButtonGroup b=new ButtonGroup();
 b121=new JRadioButton("STD");
add(b121);
b.add(b121);
 b12=new JRadioButton("ISD");
add(b12);
b.add(b12);
 b13=new JRadioButton("LOCAL");
add(b13);
b.add(b13);
 b14=new JRadioButton("CONFERENCE");
add(b14);
b.add(b14);
b121.setBounds(680,310,100,30);
b12.setBounds(780,310,100,30);
b13.setBounds(880,310,100,30);
b14.setBounds(980,310,200,30);
JLabel lv1=new JLabel("PAYMENT MODE");
add(lv1);
lv1.setBounds(835,340,171,20);
ButtonGroup b113=new ButtonGroup();
 b21=new JRadioButton("CHEQUE/DRAFT");
add(b21);
b113.add(b21);
 bw=new JRadioButton("CASH");
add(bw);
b113.add(bw);
b21.setBounds(780,370,100,30);
bw.setBounds(880,370,100,30);
JLabel lv2=new JLabel("PAYMENT DETAIL");
add(lv2);
lv2.setBounds(835,400,171,20);
JLabel l30=new JLabel("Bank Name");
JLabel l40=new JLabel("Branch Name");
JLabel l50=new JLabel("Demand Draft no.");
JLabel l60=new JLabel("Dated");
JLabel l70=new JLabel("Security Amount");
JLabel l80=new JLabel("Rental code");
JLabel l90=new JLabel("Payment Date");
l50.setBounds(650,400,190,50);
l60.setBounds(950,400,190,50);
l70.setBounds(650,430,190,50);
l80.setBounds(950,430,190,50);
l90.setBounds(650,470,190,50);
l30.setBounds(950,470,190,50);
l40.setBounds(650,500,190,50);
add(l50);add(l80);add(l70);add(l60);
add(l90);add(l30);add(l40);
 t19= new JTextField(20);
add(t19);
t19.setBounds(780,420,130,20);
 t110= new JTextField(20);
add(t110);
t110.setBounds(1000,420,130,20);
 t111= new JTextField(20);
add(t111);
t111.setBounds(780,450,130,20);
m2=new JComboBox();
 //t112= new JTextField(20);
//add(t112);
m2.setBounds(1050,450,130,20);
 t11r= new JTextField(20);
add(t11r);
t11r.setBounds(780,480,130,20);
t1r= new JTextField(20);
add(t1r);
t1r.setBounds(780,510,130,20);

 pr=new JComboBox();
pr.addItem("SBI");pr.addItem("HSBC");pr.addItem("CITY");
pr.addItem("VIJYA");pr.addItem("UCO");
pr.addItem("UNION");pr.addItem("HDFC");
add(pr);
pr.setBounds(1030,480,80,30);

JPanel p1=new JPanel(new GridLayout(0,3));
Icon h5=new ImageIcon("CONA.jpg");
bk=new JButton(h5);
Icon h1k=new ImageIcon("RT.jpg");
 b1k=new JButton(h1k);
add(p1);
Icon h2k=new ImageIcon("RES.jpg");
b2k=new JButton(h2k);
p1.setBounds(680,560,540,50);
p1.add(bk);
p1.add(b1k);
p1.add(b2k);
b2k.addActionListener(this);
b1k.addActionListener(this);

try
{
ResultSet y2;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
y2=x.executeQuery("select rental from master");
System.out.println("inserted records ");
while(y2.next())
{
m2.addItem(y2.getString(1));
//System.out.println(y2.getString(1));
}
co.close();
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
add(m2);
bk.addActionListener(this);
bw.addActionListener(this);
b21.addActionListener(this);
}
public void actionPerformed(ActionEvent e)
{
String dj="1000";
if(e.getSource()==zx)
{
try
{
long a=9045781210L;
int row=0;
ResultSet y1;
t111.setText(dj);
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
y1=x.executeQuery("select * from ragis");
while(y1.next())
{
row=row+1;
}
if(row==0)
{
String x46= new Long(a).toString();
t18.setText(x46);
}
else
{
long d=a+row;
String x46= new Long(d).toString();
t18.setText(x46);
}
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
}
if(e.getSource()==bw)
{
t19.setText("");
t19.setEnabled(false);
t1r.setText("");
t1r.setEnabled(false);
t110.setText("");
t110.setEnabled(false);
pr.setEnabled(false);
}
if(e.getSource()==b1k)
{
sub dw1=new sub();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}

if(e.getSource()==b21)
{
t19.setText("");
t19.setEnabled(true);
t1r.setText("");
t1r.setEnabled(true);
pr.setEnabled(true);
t110.setText("");
t110.setEnabled(true);
}
if(e.getSource()==b2k)
{
t19.setText(" ");
t18.setText(" ");
t8.setText(" ");
t9.setText(" ");
t10.setText(" ");
t11.setText(" ");
t12.setText(" ");
t13.setText(" ");
t14.setText(" ");
t15.setText(" ");
t16.setText(" ");
t17.setText(" ");
t19.setText(" ");
t110.setText(" ");
t111.setText(" ");
t1r.setText(" ");
}

if(e.getSource()==bk)
{
String str,str1,str2,str3,str4,str5,str6,str7,str8,str9,str0,str11,str12,str13,str14,str15,str16,con; 
try
{
str=t18.getText();
str1=t8.getText();
str2=t9.getText();
str3=t10.getText();
str4=t11.getText();
str5=t12.getText();
str6=t13.getText();
str7=t14.getText();
str8=t15.getText();
str9=t16.getText();
str0=t17.getText();
str11=t19.getText();
str12=t110.getText();
str13=t111.getText();
//str14=t112.getText();
str16=t1r.getText();
str14=m2.getSelectedItem().toString();
con=m.getSelectedItem().toString();
String con1=m1.getSelectedItem().toString();
String d=pr.getSelectedItem().toString();
Boolean r21=b1.isSelected();
Boolean r211=b2.isSelected();
Boolean r212=b3.isSelected();
Boolean r213=b4.isSelected();
Boolean r22=b121.isSelected();
Boolean r221=b12.isSelected();
Boolean r222=b13.isSelected();
Boolean r223=b121.isSelected();

Boolean r23=b21.isSelected();
Boolean r24=bw.isSelected();
System.out.println(r21);
String gen,gen1,gen2;
gen="";
gen1="";
gen2="";
if(r21==true)
{
 gen="resi";
}
else if(r211==true)
{
 gen="buisness";
}
else if(r212==true)
{
 gen="govt";
}
else if(r213==true)
{
 gen="psu";
}

if(r22==true)
{
gen1="std";
}
else if(r221==true)
{
 gen1="isd";
}
else if(r222==true)
{
 gen1="local";
}
else if(r223==true)
{
 gen1="confe";
}


if(r23==true)
{
gen2="cheque";
}
else
{
gen2="cash";
str11="";
str16="";
d="";
}
Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
Date currentTime = localCalendar.getTime();
String currentDay = new Integer(localCalendar.get(Calendar.DATE)).toString();
String currentMonth = new Integer(localCalendar.get(Calendar.MONTH) + 1).toString();
String currentYear = new Integer(localCalendar.get(Calendar.YEAR)).toString();
StringBuffer s=new StringBuffer();
s.append(currentDay);
s.append("/");
s.append(currentMonth);
s.append("/");
s.append(currentYear);
String s45= new String(s);
t11r.setText(s45);

str15=t11r.getText();

ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into ragis values('"+ str +"', '"+ str1 +"','"+ str2 +"','"+ str3 +"', '"+ str4 +"', '"+str5+"','"+ str6 +"','"+ str7+"','" + str8 + "' ,'" + str9 + "','"+ con +"','"+ con1 +" ','" + str0 + "','"+ gen +"', '"+ gen1 +"','"+ gen2 +"','"+ str11+"','"+ str12 +"','"+ str13 +"', '"+ str14 +"','"+str15+"','"+ str16 +"','" + d + "')");
System.out.println("inserted records ");
JOptionPane.showMessageDialog(null,"Data is successfully inserted into database.");
y1=x.executeQuery("select * from ragis");
while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
co.close();
}
catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"Data cannot be inserted in database.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
JOptionPane.showMessageDialog(null,"Data cannot be inserted in database.");
System.out.println(x.getMessage());
}
}

}

public static void main(String ay[])
{
regis32 d12=new regis32();
d12.setBounds(0,0,1200,700);
d12.setVisible(true);
d12.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}

