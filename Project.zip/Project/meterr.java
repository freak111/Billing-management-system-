import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.lang.Number;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.io.IOException;
public class meterr extends JFrame implements ActionListener,FocusListener
{
JButton s1g,s11,bu;
JTextField t,t1,t2,t3,t4,t5,p,mo,t6,t7,t8,t9,t17,t19;
JTextField j,dt,ta,d_date;
JLabel l_dt;

JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public meterr()
{
Container c=getContentPane();
setLayout(null);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k6.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,620,1500,70);
Color j11=new Color(130,21,11,141);
to.setBackground(j11);
Font ts=new Font("Agency FB",Font.BOLD,20);
k.setFont(ts);k2.setFont(ts);
k1.setFont(ts);k7.setFont(ts);
k3.setFont(ts);k4.setFont(ts);k6.setFont(ts);
Color j1=new Color(230,21,131,141);
k.setForeground(j1);
k1.setForeground(j1);
k3.setForeground(j1);
k4.setForeground(j1);
k2.setForeground(j1);k6.setForeground(j1);
k7.setForeground(j1);

Font rte=new Font("Aparajita",Font.BOLD,20);


JLabel l0=new JLabel("Telephone no");
l0.setBounds(240,250,200,20);
add(l0);
JLabel l4=new JLabel("Bill Generation");
add(l4);
l4.setBounds(360,190,500,40);
JLabel l=new JLabel("Name");
add(l);
l.setBounds(240,300,300,20);
JLabel l1=new JLabel("Address");
//add(l1);
l1.setBounds(240,305,300,20);
JLabel l2=new JLabel("Rental Code");
add(l2);
l2.setBounds(240,345,300,20);
JLabel l5=new JLabel("Local Calls");
add(l5);
l5.setBounds(240,385,400,20);
JLabel l6=new JLabel("STD Calls");
add(l6);
l6.setBounds(240,425,400,20);
JLabel l7=new JLabel("ISD Calls");
add(l7);
l7.setBounds(240,470,400,20);
JLabel l8=new JLabel("Rental Amount in Rs");
add(l8);
l8.setBounds(240,530,400,20);
JLabel l9=new JLabel("Total ISD");
add(l9);
l9.setBounds(790,462,100,20);
JLabel l12=new JLabel("Total  STD");
add(l12);
l12.setBounds(790,425,100,20);
JLabel l15=new JLabel("Total LOCAL");
add(l15);
l15.setBounds(790,385,100,20);
JLabel l13=new JLabel("Total Amount without Tax");
add(l13);
l13.setBounds(240,495,400,20);
JLabel l14=new JLabel("Time & Date");
add(l14);
l14.setBounds(100,525,190,40);
add(l14);
JLabel l151=new JLabel("Total Amt");
add(l151);
l151.setBounds(790,485,100,20);
 ta =new JTextField(30);
ta.setBounds(880,485,100,20);
add(ta);

t =new JTextField(30);
add(t);
t.setBounds(610,300,100,20);
 t1 =new JTextField(30);
//add(t1);
t1.setBounds(610,290,200,20);
 t2 =new JTextField(30);
add(t2);
t2.setBounds(610,330,100,20);            
 t3 =new JTextField(30);
t3.setBounds(610,380,100,20);
add(t3);
 t4 =new JTextField(30);
t4.setBounds(610,410,100,20);
add(t4);
 t5 =new JTextField(30);
t5.setBounds(610,450,100,20);
add(t5);
 t6 =new JTextField(30);
add(t6);
t6.setBounds(890,420,100,20);
 t7 =new JTextField(30);
t7.setBounds(890,380,100,20);
add(t7);
 t9 =new JTextField(30);
t9.setBounds(890,460,100,20);
add(t9);
j=new JTextField();
j.setBounds(610,250,180,20);
add(j);
 t19 =new JTextField(30);
t19.setBounds(610,500,50,20);
add(t19);
mo=new JTextField(10);
mo.setBounds(610,530,60,30);
add(mo);
Icon vf=new ImageIcon("line.jpg");
JLabel sf=new JLabel(vf);
sf.setBounds(295,220,400,10);
add(sf);
Color jv=new Color(130,10,11,114);
c.setBackground(jv);

l.setFont(rte);
l1.setFont(rte);
l2.setFont(rte);
l0.setFont(rte);
l4.setFont(rte);
l5.setFont(rte);
l6.setFont(rte);
l7.setFont(rte);
l8.setFont(rte);
l12.setFont(rte);l15.setFont(rte);
l9.setFont(rte);l151.setFont(rte);
l13.setFont(rte);l14.setFont(rte);
Font rte1=new Font("Aparajita",Font.BOLD,40);
l4.setFont(rte1);
//Icon v=new ImageIcon("CONA.jpg");
 //s1=new JButton(v);
//add(s1);
//s1.addActionListener(this);
//s1.setBounds(280,500,170,50);



Icon i3=new ImageIcon("ban2.jpg");
JLabel e1=new JLabel(i3);
e1.setBounds(0,0,1343,186);
add(e1);
l_dt = new JLabel("Due Date");
l_dt.setBounds(750,520,70,20);
 d_date =new JTextField(30);
d_date.setBounds(850,520,100,20);
l_dt.setFont(rte);
add(ta);
add(l_dt);
add(d_date); 




l4.setForeground(Color.green);
dt=new JTextField(30);
dt.setBounds(150,560,90,40);
add(dt);

Icon vg=new ImageIcon("CONA.jpg");
bu=new JButton(vg);
bu.setBounds(770,550,170,50);
add(bu);
Icon v1=new ImageIcon("RES.jpg");
s11=new JButton(v1);
add(s11);
s11.setBounds(970,550,170,50);
s11.addActionListener(this);

j.addFocusListener(this);
bu.addActionListener(this);
}
public void focusGained(FocusEvent ew)
{
System.out.println("**********hello");
}
public void focusLost(FocusEvent et)
{
String currentDay1;
Statement x1;
try
{
String s=j.getText();
System.out.println(s);
Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
Date currentTime = localCalendar.getTime();
String currentDay = new Integer(localCalendar.get(Calendar.DATE)).toString();
String currentMonth = new Integer(localCalendar.get(Calendar.MONTH) + 1).toString();
String currentYear = new Integer(localCalendar.get(Calendar.YEAR)).toString();
StringBuffer s89=new StringBuffer();
s89.append(currentDay);
s89.append("/");
s89.append(currentMonth);
s89.append("/");
s89.append(currentYear);
String s45= new String(s89);
dt.setText(s45);
int rt1=Integer.parseInt(currentDay);
if(rt1>24)
{
currentDay1 = new Integer(localCalendar.get(Calendar.DATE)+7).toString();
currentMonth = new Integer(localCalendar.get(Calendar.MONTH) + 2).toString();
}
else
{
//int s=new Integer(localCalendar.get(Calendar.DATE)+7);
currentDay1 = new Integer(localCalendar.get(Calendar.DATE)+7).toString();
currentMonth = new Integer(localCalendar.get(Calendar.MONTH) + 1).toString();
}
StringBuffer s99=new StringBuffer();
s99.append(currentDay1);
s99.append("/");
s99.append(currentMonth);
s99.append("/");
s99.append(currentYear);
String s451= new String(s99);
d_date.setText(s451);
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","","");
System.out.println("Connected successfully");
 x1=co.createStatement();
ResultSet y=x1.executeQuery("select name, rental_code from ragis where cust_id ='" + s +"'");

while(y.next())
{
t.setText(y.getString(1));
t2.setText(y.getString(2));
}
String rt=j.getText();
Statement x2=co.createStatement();
ResultSet y1=x2.executeQuery("select t_local,t_std,t_isd from meter where no ='" + rt + "'");
while(y1.next())
{
t7.setText(y1.getString(1));
t6.setText(y1.getString(2));
t9.setText(y1.getString(3));
}
Statement x5=co.createStatement();
String s5=t2.getText();
ResultSet y4=x5.executeQuery("select local,isd,std,plan_code from master where rental ='" + s5 + "'");
while(y4.next())
{
t3.setText(y4.getString(1));
t4.setText(y4.getString(2));
t5.setText(y4.getString(3));
mo.setText(y4.getString(4));
}

float g=Float.parseFloat(t7.getText());
float g1=Float.parseFloat(t3.getText());

float g2=Float.parseFloat(t4.getText());
float g3=Float.parseFloat(t6.getText());

float g4=Float.parseFloat(t5.getText());
float g5=Float.parseFloat(t9.getText());
float f=Float.parseFloat(mo.getText());;
f=f+(g*g1+g2*g3+g4*g5);
String alpha= new Float(f).toString();
t19.setText(alpha);
float t_bill= (f*10)/100 +f;
String s_b=new Float(t_bill).toString();
ta.setText(s_b);
System.out.println(t_bill);
System.out.println(g);
System.out.println(f);
System.out.println("***********************************");
co.close();
}

catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}

}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==s11)
{
t.setText("");t1.setText("");t2.setText("");t3.setText("");t4.setText("");t5.setText("");t6.setText("");t7.setText("");t8.setText("");t9.setText("");t17.setText("");t19.setText("");j.setText("");dt.setText("");mo.setText("");p.setText("");
}  
if(e.getSource()==k)                                 
{
login121 dw1=new login121();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k4)
{
query1 dw1=new query1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k6)
{
piz1 dw1=new piz1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}



if(e.getSource()==bu)
{
System.out.println("clicked me");
String str,str1,str3,str4,str5,str6,str7;
try
{
str=j.getText();
System.out.println(str);
//str1=t1.getText();
float str2=Float.parseFloat(t19.getText());
str3=dt.getText();
System.out.println(str2);
//int r= Integer.parseInt(str);
//int r1= Integer.parseInt(str2);
//int n= Integer.parseInt(str2);
//n=((n*10)/100)+n;
float f1=Float.parseFloat(ta.getText());
//ta.setText(f1);
ResultSet y;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into bill(Telephone_no,amt_bef_tax,amt_af_Tax,date_bill) values('"+ str +"' , '"+ str2 +"', '"+ f1 +"', '"+ str3 +"')");
System.out.println("inserted records ");
JOptionPane.showMessageDialog(null,"Data submitted into database.");
y=x.executeQuery("select * from bill");
while(y.next())
System.out.println(y.getString(1)+ "\t" + y.getString(2)+"\t" + y.getString(3)+"\t");
co.close();
}
catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"Data cannot be submitted into database.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
JOptionPane.showMessageDialog(null,"Data cannot be submitted into database.");
System.out.println(x.getMessage());
}
}
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}


public static void main(String ad[])
{
meterr er=new meterr();
er.setBounds(0,0,1200,700);
er.setVisible(true);
er.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}
