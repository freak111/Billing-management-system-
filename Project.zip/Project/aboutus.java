import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.IOException;
public class aboutus extends JFrame implements ActionListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("COMPLAIN",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));

public aboutus()
{
Container c=getContentPane();
setLayout(null);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);k6.addActionListener(this);
k2.addActionListener(this);

to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();

add(to,BorderLayout.SOUTH);
to.setBounds(0,630,1500,50);
Color j11=new Color(110,211,111,41);
to.setBackground(j11);
Icon i=new ImageIcon("Copy of hawk-critic-468x60 - Copy.gif");
JLabel e1=new JLabel(i);
e1.setBounds(880,560,468,60);
//add(e1);
Icon i1=new ImageIcon("aboutus1.jpg");
JLabel e11=new JLabel(i1);
e11.setBounds(360,50,613,543);
add(e11);

Icon i4=new ImageIcon("SideAI.jpg");
JLabel e14=new JLabel(i4);
e14.setBounds(130,80,114,481);
add(e14);

Icon i41=new ImageIcon("SideAI.jpg");
JLabel e141=new JLabel(i41);
e141.setBounds(1030,80,114,481);
add(e141);
setBackground(Color.red);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
login121 dw1=new login121();
dw1.setBounds(0,0,1000,1000);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1000,1000);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k4)
{
query1 dw1=new query1();
dw1.setBounds(0,0,1000,1000);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1000,1000);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1000,1000);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k6)
{
piz1 dw1=new piz1();
dw1.setBounds(0,0,1000,1000);
dw1.setVisible(true);
dispose();
}

}

public static void main(String ad[])
{
aboutus dw1=new aboutus();
dw1.setBounds(200,200,400,400);
dw1.setVisible(true);
dw1.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}
