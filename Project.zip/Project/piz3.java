import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
public class piz3 extends JFrame implements ActionListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("TRANSECTION",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public piz3()
{
Container c=getContentPane();
setLayout(null); 
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,600,1500,90);
Color j11=new Color(110,211,111,41);
to.setBackground(j11);

Font e=new Font("Nyala",Font.BOLD,20);
Font ts=new Font("Aparajita",Font.BOLD,20);
Font ts1=new Font("Aparajita",Font.BOLD,14);
JLabel l=new JLabel("UserLogin",Label.LEFT);
JLabel l1=new JLabel("Enter your name");
JLabel l2=new JLabel("Customer ID");
JLabel l3=new JLabel("Enter your email");
JLabel l4=new JLabel("Sex");
JLabel l5=new JLabel("Parmanent Address");
JLabel l6=new JLabel("Service Required");
JPasswordField t1=new JPasswordField(10);;
JTextField t=new JTextField();
JTextField t2=new JTextField();
ButtonGroup bw=new ButtonGroup();
JRadioButton c1=new JRadioButton("FEMALE",false);

JRadioButton c2=new JRadioButton("MALE",true);

JTextField t4=new JTextField();
JTextField t5=new JTextField();
Icon h=new ImageIcon("confirm.jpg");
JButton b=new JButton(h);
Icon hl=new ImageIcon("cancel.jpg");
JButton b1=new JButton(hl);
Icon h2=new ImageIcon("reset.jpg");
JButton b2=new JButton(h2);
Icon h3=new ImageIcon("clear.jpg");
JButton b3=new JButton(h3);
setLayout(null);
l.setBounds(300,200,120,30);
l1.setBounds(20,250,120,30);
l2.setBounds(20,300,220,30);
l3.setBounds(20,350,120,30);
l4.setBounds(20,400,300,30);

l5.setBounds(20,450,220,30);
l6.setBounds(20,500,120,30);
t.setBounds(250,250,300,40);
t1.setBounds(250,300,300,40);
t2.setBounds(250,350,300,40);
c1.setBounds(260,400,170,40);
c2.setBounds(500,400,170,40);
t4.setBounds(250,450,300,40);
t5.setBounds(250,500,300,40);
b.setBounds(80,560,180,30);
b1.setBounds(270,560,180,30);
b2.setBounds(470,560,180,30);
b3.setBounds(700,560,180,30);
add(l);
add(l1);
add(l2);
add(l3);
add(l4);
add(l5);
add(l6);
add(t);
add(t1);
add(t2);
add(t4);
add(t5);
add(b);
add(b1);
add(c1);
add(c2);
add(b2);
add(b3);
b1.setFont(e);
b2.setFont(e);
b3.setFont(e);
b.setFont(e);
l.setFont(ts);
l1.setFont(ts);
l2.setFont(ts);
l3.setFont(ts);
l4.setFont(ts);
l5.setFont(ts);
l6.setFont(ts);
c1.setFont(ts1);
c2.setFont(ts1);
l.setForeground(Color.blue);
l1.setForeground(Color.red);
l2.setForeground(Color.red);
l3.setForeground(Color.red);
l4.setForeground(Color.red);
l5.setForeground(Color.red);
l6.setForeground(Color.red);
c1.setForeground(Color.red);
c2.setForeground(Color.red);

Icon i=new ImageIcon("furn_TEL.gif");
JLabel s1=new JLabel(i);
s1.setBounds(890,180,160,260);
add(s1);
bw.add(c2);
bw.add(c1);

Icon i3=new ImageIcon("ban3.jpg");
JLabel e1=new JLabel(i3);
e1.setBounds(0,0,1343,186);
add(e1);

}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
login121 obj2 = new login121();
obj2.setVisible(true);
obj2.setSize(1000,600);
dispose();
}
}

public static void main(String ad[])
{
piz3 dw1=new piz3();
dw1.setBounds(200,200,400,400);
dw1.setVisible(true);
}
}
/*<applet code="piz3" height=555 width=555>
</applet>*/