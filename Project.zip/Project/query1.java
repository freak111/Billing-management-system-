import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.IOException;
import java.applet.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.io.IOException;
public class query1 extends JFrame implements ActionListener
{
JRadioButton c1;
JButton s11,s1g,s1;
JTextField t,t1,t2;
JTextArea t3;
JComboBox x11,p,mo;
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("COMPLAIN",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public query1()
{

Container c=getContentPane();
ButtonGroup b;
setLayout(null);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
//to.add(k4);
//to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,630,1570,50);
Color j11=new Color(110,211,100,25);
to.setBackground(j11);

JLabel l4=new JLabel("Complaint");
add(l4);
l4.setBounds(260,170,500,40);
JLabel l=new JLabel("Enter Your Mobile Number");
add(l);
l.setBounds(40,260,300,30);
JLabel l1=new JLabel("Unique ID");
add(l1);
l1.setBounds(40,300,300,30);

JLabel l2=new JLabel("Name");
add(l2);
l2.setBounds(40,340,300,30);
JLabel l5=new JLabel("Enter Your Complaint date");
add(l5);
l5.setBounds(40,380,400,30);
JLabel l6=new JLabel("You con type here your Complaint");
add(l6);
l6.setBounds(40,430,400,30);

 t3 = new JTextArea();
add(t3);
t =new JTextField(30);
add(t);
t.setBounds(410,260,200,30);
t1 =new JTextField(30);
add(t1);
t1.setBounds(410,300,200,30);
t2 =new JTextField(30);
add(t2);
t2.setBounds(410,340,200,30);
Color jv=new Color(130,10,11,114);
c.setBackground(jv);
Font rte=new Font("Aparajita",Font.BOLD,30);
l.setFont(rte);
l1.setFont(rte);
l2.setFont(rte);
l5.setFont(rte);
l6.setFont(rte);
Font rte1=new Font("Aparajita",Font.BOLD,40);
l4.setFont(rte1);

Icon v=new ImageIcon("CONA.jpg");
 s1=new JButton(v);
add(s1);
s1.setBounds(180,580,160,50);
Icon v1=new ImageIcon("RES.jpg");
 s11=new JButton(v1);
add(s11);
s11.setBounds(460,580,160,50);

l4.setForeground(Color.green);
Icon vf=new ImageIcon("line.jpg");
JLabel sf=new JLabel(vf);
sf.setBounds(200,210,300,10);
add(sf);

x11=new JComboBox();
x11.addItem("Day");x11.addItem("1");x11.addItem("2");
x11.addItem("3");x11.addItem("4");x11.addItem("5");
x11.addItem("6");x11.addItem("7");x11.addItem("8");x11.addItem("9");
x11.addItem("10");x11.addItem("11");x11.addItem("12");x11.addItem("13");
x11.addItem("14");x11.addItem("15");x11.addItem("16");
x11.addItem("17");x11.addItem("18");x11.addItem("19");
x11.addItem("20");x11.addItem("21");x11.addItem("23");
x11.addItem("24");x11.addItem("25");x11.addItem("26");
x11.addItem("27");x11.addItem("28");x11.addItem("29");
x11.addItem("30");x11.addItem("31");
p=new JComboBox();
p.addItem("Month");p.addItem("Jan");p.addItem("Feb");
p.addItem("Mar");p.addItem("Jun");p.addItem("Jul");
p.addItem("Aug");p.addItem("Sep");p.addItem("Oct");p.addItem("Nov");
p.addItem("Dec");p.addItem("Oct");p.addItem("nov");p.addItem("Dec");
 mo=new JComboBox();
mo.addItem("Year");mo.addItem("2013");
x11.setBounds(390,380,50,30);
p.setBounds(450,380,80,30);mo.setBounds(540,380,80,30);
add(x11);add(p);add(mo);

JPanel jaa=new JPanel();
 b=new ButtonGroup();
c1=new JRadioButton("LandLine",false);
b.add(c1);
jaa.add(c1);
add(jaa);
c1.setFont(rte);
c1.setBounds(70,230,200,20);
JRadioButton c2=new JRadioButton("BroadBand",false);
b.add(c2);
jaa.add(c2);
c2.setFont(rte);
c2.setBounds(350,230,200,20);
c1.setBackground(jv);
c2.setBackground(jv);
c1.setForeground(Color.white);
c2.setForeground(Color.white);
t1.addActionListener(this);
t2.addActionListener(this);
s1.addActionListener(this);
t.addActionListener(this);
s11.addActionListener(this);
Icon i=new ImageIcon("ban4.jpg");
JLabel e1=new JLabel(i);
e1.setBounds(0,0,1343,186);
add(e1);
JScrollPane jd=new JScrollPane(t3,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
add(jd);
jd.setBounds(410,430,200,130);
}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==s11)
{
t.setText("");t1.setText("");t2.setText("");t3.setText("");
}
if(e.getSource()==s1)
{
String r,r1,r3;
r=t1.getText();
int u=r.length();
r1=t2.getText();
int p2=r1.length();
r3=t.getText();
int p1=r3.length();
if(u==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
else if(p2==0)
{
JOptionPane.showConfirmDialog((Component)null,"Enter Your Account Number","Error",JOptionPane.OK_CANCEL_OPTION);  
}
else if(p1==0)
{
JOptionPane.showConfirmDialog((Component)null,"Enter Your Mobile Number","Error",JOptionPane.OK_CANCEL_OPTION);  
}
else if(p1<10||p1>10)
{
JOptionPane.showConfirmDialog((Component)null,"Mobile Number must be 10 Digit","Error",JOptionPane.OK_CANCEL_OPTION);  
}
String str,str1,str2,str8,str3; 
try
{
str=t.getText();
str1=t1.getText();
str2=t2.getText();
str3=t3.getText();
String con1=x11.getSelectedItem().toString();
String con2=p.getSelectedItem().toString();
String con3=mo.getSelectedItem().toString();
str8=con1+con2+con3;

ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into comp values(' "+ str +" ','"+ str1 +"','"+ str2 +"','"+ str8 +"','"+ str3 +"')");
JOptionPane.showMessageDialog(null,"Data is successfully submitted into database.");
System.out.println("inserted records ");
y1=x.executeQuery("select * from comp");
while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
co.close();
}
catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"Data is not submitted into database.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
JOptionPane.showMessageDialog(null,"Data is not submitted into database.");
System.out.println(x.getMessage());
}

}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
 if(e.getSource()==k)
{
sub obj2 = new sub();
obj2.setVisible(true);
obj2.setBounds(0,0,1200,700);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
if(e.getSource()==k6)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
if(e.getSource()==k7)
{
aboutus dw1=new aboutus();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
}
public static void main(String dw[])
{
query1 d=new query1();
d.setBounds(0,0,1200,700);
d.setVisible(true);
d.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}

