import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
public class query extends JFrame implements ActionListener
{
JButton s1g;
public query()
{
Container c=getContentPane();
setLayout(null);
JLabel l4=new JLabel("Query Transaction");
add(l4);
l4.setBounds(360,30,500,40);
JLabel l=new JLabel("Enter Your Mobile Number");
add(l);
l.setBounds(140,100,300,30);
JLabel l1=new JLabel("Unique ID");
add(l1);
l1.setBounds(140,140,300,30);
JLabel l2=new JLabel("Account Number");
add(l2);
l2.setBounds(140,180,300,30);
l2.setBounds(140,180,300,30);
JTextField t =new JTextField(30);
add(t);
t.setBounds(510,100,200,30);
JTextField t1 =new JTextField(30);
add(t1);
t1.setBounds(510,140,200,30);
JTextField t2 =new JTextField(30);
add(t2);
t2.setBounds(510,180,200,30);
Color jv=new Color(130,10,11,114);
c.setBackground(jv);
Font rte=new Font("Aparajita",Font.BOLD,30);
l.setFont(rte);
l1.setFont(rte);
l2.setFont(rte);
Font rte1=new Font("Aparajita",Font.BOLD,40);
l4.setFont(rte1);

Icon v=new ImageIcon("CONA.jpg");
JButton s1=new JButton(v);
add(s1);

s1.setBounds(280,250,170,50);
Icon v1=new ImageIcon("RES.jpg");
JButton s11=new JButton(v1);
add(s11);
s11.setBounds(490,250,170,50);

l4.setForeground(Color.green);
Icon vf=new ImageIcon("line.jpg");
JLabel sf=new JLabel(vf);
sf.setBounds(300,60,360,10);
add(sf);
Icon vs=new ImageIcon("com.jpg");
JLabel lo=new JLabel(vs);
add(lo);
lo.setBounds(190,350,109,176);

Icon vg=new ImageIcon("co.jpg");
 s1g=new JButton(vg);
add(s1g);
s1g.addActionListener(this);
s1g.setBounds(20,300,161,109);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==s1g)
{


query1 obj2 = new query1();
setSize(1000,900);
setVisible(true);

}
}
public static void main(String ad[])
{
query er=new query();
er.setBounds(200,200,1000,900);
er.setVisible(true);

}
}
/*<applet code="query" height=500 width=500></applet>*/
