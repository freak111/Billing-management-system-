import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.awt.Dimension;
import java.util.*;
import java.awt.*;
import javax.swing.table.JTableHeader;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
public class vriksha extends JFrame implements ActionListener
{
JLabel l1,l2,l3,l4,l5,l6,l7,l8,lh;
JButton b,b1,b2,b3,b6,b7,b8;
JTextArea t;
Font f1,f2;
JPanel panel;
vriksha()
{
setLayout(null);
Container c=getContentPane();
//c.setBackground(Color.RED);
panel=new JPanel();
l1=new JLabel();
//l1.setIcon(new ImageIcon("individual-health-insurance.jpg"));
//l1.setBounds(450,5,500,167);
l2=new JLabel();
l2.setIcon(new ImageIcon("vriksha.jpg"));
l2.setBounds(50,180,212,272);
l3=new JLabel();
//l3.setIcon(new ImageIcon("wn.jpg"));
l3.setBounds(0,170,1400,700);
lh=new JLabel();
lh.setIcon(new ImageIcon("Ch.jpg"));
lh.setBounds(50,470,227,197);
l5=new JLabel();
l5.setIcon(new ImageIcon("ri.jpg"));
l5.setBounds(300,180,194,121);
b1=new JButton("Key Feature");
b1.setBackground(Color.BLUE);
b1.setForeground(Color.WHITE);
b1.setBounds(350,350,130,30);
add(b1);

add(lh);

b=new JButton();
b.setIcon(new ImageIcon("home.jpg"));
//b.setForeground(Color.BLUE);
//b.setBackground(Color.GREEN);
b.setBounds(680,95,67,30);
add(b);

b7=new JButton("AGENT REGISTRATION");
b7.setBackground(Color.orange);
b7.setForeground(Color.BLUE);
b7.setBounds(750,100,170,25);
add(b7);


b8=new JButton("CUSTOMER REGISTRATION");
b8.setBackground(Color.GREEN);
b8.setForeground(Color.BLUE);
b8.setBounds(921,100,210,25);
add(b8);
b2=new JButton("Annual Premium");
b2.setBackground(Color.BLUE);
b2.setForeground(Color.WHITE);
b2.setBounds(350,450,130,30);
b3=new JButton("Create Policy");
b3.setBackground(Color.BLUE);
b3.setForeground(Color.WHITE);
b3.setBounds(350,550,130,30);
add(b3);


b6=new JButton("Create Policy");
b6.setBackground(Color.BLUE);
b6.setForeground(Color.WHITE);
b6.setBounds(1131,100,130,25);
add(b6);



f2=new Font("Times New Roman",Font.BOLD,20);
l6=new JLabel("Key Feature");
l6.setFont(f2);
l4=new JLabel();
l4.setIcon(new ImageIcon("nirmala.jpg"));
l4.setBounds(30,15,307,150);
add(l4);

l6.setBounds(700,190,150,70);
add(l6);
f2=new Font("Times New Roman",Font.BOLD,20);
l7=new JLabel("Annual Premium");
l7.setFont(f2);
l7.setBounds(1000,190,150,70);
add(l7);
f1=new Font("Times New Roman",Font.BOLD,25);
l8=new JLabel("NIRMALA VRIKSHA PLAN");
l8.setForeground(Color.WHITE);
l8.setFont(f1);
l8.setBounds(245,120,350,70);
add(l8);
add(b2);
add(l1);
add(l2);
add(l4);
add(l5);
add(l3);
b3.addActionListener(this);
b6.addActionListener(this);
b7.addActionListener(this);
b8.addActionListener(this);
b.addActionListener(this);
b2.addActionListener(this);
}


public void actionPerformed(ActionEvent e)
{

if(e.getSource()==b2)
{
try
{
DefaultTableModel tablemodel = new DefaultTableModel(); 
int row1=0;
Connection con;
ResultSet y;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
con=DriverManager.getConnection("jdbc:odbc:pankaj","insurance","");
System.out.println("connected sucessfully");
Statement st=con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
y=st.executeQuery("select * from master");
System.out.println("selected record from master");
Container c=getContentPane();
ResultSetMetaData v=y.getMetaData();
int col=v.getColumnCount();
System.out.println("col=" +col);
while(y.next())
{
row1=row1+1;
System.out.println(y.getString(1));
}
int i;
System.out.println("row=" +row1);
Vector co=new Vector(col);
for(i=1; i<=col;i++)
{
String columnName = v.getColumnName(i);
co.addElement(columnName);
System.out.println(columnName);
}
/*for(i=1; i<=col;i++)
{    
co.addElement(v.getColumnName(i));
}*/
Vector data=new Vector();
Vector row;
y.beforeFirst();
while(y.next())
{
row=new Vector(col);
for(i=1; i<=col;i++)
{
row.add(y.getString(i));
}

data.add(row);
System.out.println("sdasdfsagdasdgsa");
}
//JFrame frame=new JFrame("Showing Customer detail");
JTable table= new JTable(data,co);
JScrollPane scroll = new JScrollPane(table);
panel.setBackground(Color.blue);
//scroll.setLayout(null);
scroll.setBounds(550,750,800,800);
panel.add(scroll);
panel.setBounds(450,700,1000,1000);
add(panel);

panel.setVisible(true);
}

catch(Exception e2)
{
System.out.println(e2);
}
}
if(e.getSource()==b3)
{
newpolicy obj=new newpolicy();
obj.setSize(1000,1000);
obj.setVisible(true);
dispose();
}


if(e.getSource()==b)
{
p obj=new p();
obj.setSize(1000,1000);
obj.setVisible(true);
dispose();
}




if(e.getSource()==b6)
{
newpolicy obj=new newpolicy();
obj.setSize(1000,1000);
obj.setVisible(true);
dispose();
}



if(e.getSource()==b8)
{
req obj=new req();
obj.setSize(1000,1000);
obj.setVisible(true);
dispose();
}



if(e.getSource()==b7)
{
agent obj=new agent();
obj.setSize(1000,1000);
obj.setVisible(true);
dispose();
}







}	
public static void main(String args[])
{
vriksha one =new vriksha();
one.setSize(1000,1000);
one.setDefaultCloseOperation(EXIT_ON_CLOSE);
one.setVisible(true);
}
}