import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.lang.Number;
import java.io.IOException;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.io.IOException;
public class meter extends JFrame implements ActionListener,FocusListener
{
JButton s1g,s1;
JTextField t,t1,t2,t3,t4,t5,p,mo; 
Font tr=new Font("Forte",Font.BOLD,18);
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));

public meter()
{
Container c=getContentPane();
setLayout(null);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k6.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,650,1500,60);
Icon i6=new ImageIcon("ban4.jpg");
JLabel e16=new JLabel(i6);
e16.setBounds(0,0,1343,186);
add(e16);



JLabel l4=new JLabel("METER READING");
add(l4);
l4.setBounds(360,230,500,40);
JLabel l=new JLabel("Enter Your Mobile Number");
add(l);
l.setBounds(240,280,300,20);
JLabel l1=new JLabel("Customer ID");
//add(l1);
l1.setBounds(240,240,300,20);
JLabel l2=new JLabel("Rental Code");
//add(l2);
l2.setBounds(240,280,300,20);
JLabel l5=new JLabel("Total Local Calls");
add(l5);
l5.setBounds(240,320,400,20);
JLabel l6=new JLabel("Total STD Calls");
add(l6);
l6.setBounds(240,360,400,20);
JLabel l7=new JLabel("Total ISD Calls");
add(l7);
l7.setBounds(240,400,400,20);
JLabel l8=new JLabel("Total Free Calls");
//add(l8);
l8.setBounds(240,440,400,20);
JLabel l9=new JLabel("month & Year");
add(l9);
l9.setBounds(240,440,400,20);


t =new JTextField(30);
add(t);
t.setBounds(610,280,200,20);
 t1 =new JTextField(30);
//add(t1);
t1.setBounds(610,240,200,20);
 t2 =new JTextField(30);
//add(t2);
t2.setBounds(610,380,200,20);
 t3 =new JTextField(30);
t3.setBounds(610,320,200,20);
add(t3);
 t4 =new JTextField(30);
t4.setBounds(610,360,200,20);
add(t4);
 t5 =new JTextField(30);
t5.setBounds(610,400,200,20);
add(t5);

Icon vf=new ImageIcon("line.jpg");
JLabel sf=new JLabel(vf);
sf.setBounds(300,260,400,10);
add(sf);
 mo=new JTextField(10);
 p=new JTextField(10);
p.setBounds(610,440,120,30);
mo.setBounds(610,440,120,30);
//add(p);
add(mo);
Color jv=new Color(130,10,11,114);
c.setBackground(jv);
Font rte=new Font("Aparajita",Font.BOLD,20);
l.setFont(rte);
l1.setFont(rte);
l2.setFont(rte);
l9.setFont(rte);
l4.setFont(rte);
l5.setFont(rte);
l6.setFont(rte);
l7.setFont(rte);
l8.setFont(rte);
Font rte1=new Font("Aparajita",Font.BOLD,40);
l4.setFont(rte1);
Icon v=new ImageIcon("CONA.jpg");
 s1=new JButton(v);
add(s1);
s1.addActionListener(this);
s1.setBounds(280,530,170,50);
Icon v1=new ImageIcon("RES.jpg");
JButton s11=new JButton(v1);
add(s11);
s11.setBounds(490,530,170,50);


l4.setForeground(Color.green);


Icon vg=new ImageIcon("co.jpg");
 s1g=new JButton(vg);
add(s1g);

s1g.setBounds(20,750,161,4109);
t.addFocusListener(this);
Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
Date currentTime = localCalendar.getTime();
String currentDay = new Integer(localCalendar.get(Calendar.DATE)).toString();
String currentMonth = new Integer(localCalendar.get(Calendar.MONTH)).toString();
String currentYear = new Integer(localCalendar.get(Calendar.YEAR)).toString();
StringBuffer s89=new StringBuffer();
s89.append(currentMonth);
s89.append("/");
s89.append(currentYear);
String s45= new String(s89);
mo.setText(s45);

}
public void focusGained(FocusEvent ew)
{
}
public void focusLost(FocusEvent e)
{
int w= 0;
try
{
String sg=t.getText();
ResultSet y2;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x1=co.createStatement();

y2=x1.executeQuery("select * from ragis where cust_id= '" + sg +"'");
int row12=0;
while(y2.next())
{
row12=row12+1;
System.out.println(y2.getString(1));
System.out.println(y2.getString(2));
System.out.println(y2.getString(3));
System.out.println(y2.getString(4));
}
if(row12==0)
{
JOptionPane.showMessageDialog(null,"Invalid Phone No.");
t.setText("");
t.requestFocus();
}
/*while(y2.next())
{
 w=y2.getInt(3);
System.out.println(w);
}*/
String po=t4.getText();
int s_std=Integer.parseInt(po);
System.out.println(s_std);
int r1= s_std*w;
System.out.println("\n sadsadsad " + r1);
/*while(y2.next())
{
System.out.println(y2.getString(1));
p.setText(y2.getString(4));
System.out.println(s_std);
System.out.println(r1);
}*/

}

catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"cannot find phone no entry.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
JOptionPane.showMessageDialog(null,"cannot find phone no entry");
System.out.println(x.getMessage());
}


}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==s1)
{

String str,str1,str2,str3,str4,str5,str6,str7;
{
try
{
str=t.getText();
//str1=t1.getText();
//str2=t2.getText();
str3=t3.getText();
str4=t4.getText();
str5=t5.getText();
//str6=p.getText();
str7=mo.getText();




//String d=c1.getSelectedItem().toString();
//System.out.println(d);
//System.out.println(coun);
//String d1=c2.getSelectedItem().toString();
//System.out.println(d1);
//String d2=c3.getSelectedItem().toString();
//System.out.println(d2);
//Boolean r21=b1.isSelected();
//StringBuffer buffer = new StringBuffer(); 
//buffer.append(d).append("/").append(d1).append("/").append(d2); 
//String result = buffer.toString();
/*System.out.println(r21);
String gen;
if(r21==true)
{
 gen="resi";
}
else 
{
 gen="buisness";
}*/
ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into meter values('"+ str +" ','"+ str3 +"', '"+ str4 +"', '"+ str5 +"', '"+ str7 +"' )");
System.out.println("inserted records ");
JOptionPane.showMessageDialog(null,"Data is successfully inserted into database.");
y1=x.executeQuery("select * from meter");
while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2)+"\t" + y1.getString(3)+"\t" + y1.getString(4)+"\t" + y1.getString(5)+"\t" );
co.close();
}
catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"Data cannot be inserted in database.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
JOptionPane.showMessageDialog(null,"Data cannot be submitted into database.");
System.out.println(x.getMessage());
}
}
meterr dw1=new meterr();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
}


public static void main(String ad[])
{
meter er=new meter();
er.setBounds(0,0,1200,700);
er.setVisible(true);
er.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}
