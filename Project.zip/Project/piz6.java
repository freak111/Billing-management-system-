import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
public class piz6 extends JFrame implements ActionListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("TRANSECTION",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public piz6()
{
Container c=getContentPane();
setLayout(null); 
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,600,1500,90);
Color j11=new Color(170,11,111,41);
to.setBackground(j11);



JLabel l1=new JLabel("Enter Your first Name");
JTextField t=new JTextField();
Font rs=new Font("Arial",Font.BOLD,15);
l1.setFont(rs);
l1.setBounds(60,350,220,50);
t.setBounds(280,350,300,40);
add(l1);
add(t);
l1.setForeground(Color.blue);
Color qw=new Color(10,10,103,104);
c.setBackground(qw);
Icon hg=new ImageIcon("bg.jpg");
JButton bs=new JButton(hg);
bs.setBounds(300,450,100,70);
add(bs);
Icon ha=new ImageIcon("bu.jpg");
JButton bd=new JButton(ha);
bd.setBounds(450,450,100,70);
add(bd);
Icon i=new ImageIcon("hea1.jpg");
JLabel e1=new JLabel(i);
e1.setBounds(0,0,1343,186);
add(e1);
Font topr=new Font("Forte",Font.BOLD,25);
JLabel rb=new JLabel("SEARCH CONTACT NUMBER");
rb.setBounds(280,250,360,30);
rb.setForeground(Color.green);
add(rb);
rb.setFont(topr);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
login121 obj2 = new login121();
obj2.setVisible(true);
obj2.setSize(1000,600);
}
}
public static void main(String ad[])
{
piz6 dw1=new piz6();
dw1.setBounds(200,200,400,400);
dw1.setVisible(true);
}
}
/*<applet code="piz6" height=555 width=555>
</applet>*/