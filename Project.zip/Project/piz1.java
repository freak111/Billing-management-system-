import java.sql.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.util.*;
import java.awt.*;
import javax.swing.table.JTableHeader;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
import java.io.IOException;
public class piz1 extends JFrame implements ActionListener
{
JButton bs,bd;
JPanel panel;
JTextField t;
Font tr=new Font("Forte",Font.BOLD,18);
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("COMPLAIN",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
JButton s=new JButton("SEARCH BY CITY",new ImageIcon("thCALAR2U2.jpg"));
JButton sa=new JButton("Search by TLEPHONE NO",new ImageIcon("thCALAR2U2.jpg"));
//JButton sb=new JButton("Search by City",new ImageIcon("thCALAR2U2.jpg"));
public piz1()
{
panel=new JPanel();
Container c=getContentPane();
setLayout(null); 
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k6.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,600,1500,90);

Color j11=new Color(110,211,111,41);
to.setBackground(j11);
add(s);
JLabel ls=new JLabel("SEARCH BY CITY");
JLabel lsa=new JLabel("Search by TLEPHONE NO");
s.setBounds(100,170,143,112);
ls.setBounds(100,300,288,20);
ls.setBackground(j11);
add(sa);
sa.setBounds(400,170,143,112);
lsa.setBounds(400,300,288,20);
lsa.setBackground(j11);
add(ls);
add(lsa);

ls.setFont(tr);
lsa.setFont(tr);
sa.addActionListener(this);
s.addActionListener(this);
ls.setForeground(Color.red);
lsa.setForeground(Color.red);
JLabel l1=new JLabel("Enter Your First Name");
 t=new JTextField();
Font rs=new Font("Arial",Font.BOLD,15);
l1.setFont(rs);
l1.setBounds(60,400,220,50);
t.setBounds(280,400,300,40);
add(l1);
add(t);
l1.setForeground(Color.blue);
Color qw=new Color(10,10,103,104);
c.setBackground(qw);
Icon hg=new ImageIcon("bu.jpg");
bs=new JButton(hg);
bs.setBounds(300,500,100,70);
add(bs);
Icon ha=new ImageIcon("bg.jpg");
 bd=new JButton(ha);
bd.setBounds(450,500,100,70);
add(bd);
bd.addActionListener(this);
Icon i=new ImageIcon("ban4.jpg");
JLabel e1=new JLabel(i);
e1.setBounds(0,0,1343,186);
add(e1);
bs.addActionListener(this);
Font topr=new Font("Forte",Font.BOLD,25);
JLabel rb=new JLabel("SEARCH CONTACT NUMBER");
rb.setBounds(280,350,360,30);
rb.setForeground(Color.green);
add(rb);
rb.setFont(topr);

}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==bs)
{
String r;
r=t.getText();
int u=r.length();

if(u==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
}
else if(e.getSource()==bd)
{

dispose();
}
if(e.getSource()==sa)
{
last obj2 = new last();
obj2.setVisible(true);
obj2.setSize(1000,600);
dispose();
}
 if(e.getSource()==s)
{
piz8 obj2 = new piz8();
obj2.setVisible(true);
obj2.setBounds(0,0,1200,700);
dispose();
}
if(e.getSource()==k)
{
sub dw1=new sub();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k4)
{
query1 dw1=new query1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k6)
{
piz1 dw1=new piz1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==bs)
{
String s=t.getText();

try
{
DefaultTableModel tablemodel = new DefaultTableModel(); 
int row1=0;
Connection con;
ResultSet y;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
con=DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("connected sucessfully");
Statement st=con.createStatement( ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
//y1=x1.executeQuery("select cust_id from cust_reg where cust_id like //'"+'%'+str1+'%'+"'");
y=st.executeQuery("select cust_id,name,rental_code,email,pan  from ragis where name like '" + '%' + s +'%' +"'");
System.out.println("selected record from table");
Container c=getContentPane();
ResultSetMetaData v=y.getMetaData();
int col=v.getColumnCount();
System.out.print(col);
while(y.next())
{
System.out.println(y.getString(1));
}

int i;
y.beforeFirst();
while(y.next())
{
 row1=row1+1;
}
y.beforeFirst();
System.out.println(row1);
Vector co=new Vector(col);
for(i=1; i<=col;i++)
{
String columnName = v.getColumnName(i);
co.addElement(columnName);
System.out.println(columnName);
}
Vector data=new Vector();
Vector row;
y.beforeFirst();
while(y.next())
{
row=new Vector(col);
for(i=1; i<=col;i++)
{
row.add(y.getString(i));
}

data.add(row);
System.out.println("sdasdfsagdasdgsa");
}
//JFrame frame=new JFrame("Showing Customer detail");
JTable table=new JTable(data,co);
JScrollPane scroll = new JScrollPane(table);
scroll.setBounds(450,200,700,600);
panel.add(scroll);
panel.setBounds(350,150,900,400);
add(panel);
panel.setVisible(true);
}

catch(Exception e2)
{
System.out.println(e2);
}
}
}




public static void main(String ad[])
{
piz1 dw1=new piz1();
dw1.setBounds(0,0,1400,800);
dw1.setVisible(true);
dw1.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}
