import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.io.IOException;
public class piz4 extends JFrame implements ActionListener,FocusListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("MASTER",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
JButton k8=new JButton("Print Invoice",new ImageIcon("dfat.jpg"));
JButton k9=new JButton("Print Invoice",new ImageIcon("dfat.jpg"));
JTextField t,t1,t2,t3,t5,t7,t13,t9,t10,bd;
JComboBox x,m,m1,x1,p,mo,pr1;
JRadioButton c1,c2;
JButton b,b1,b2;
public piz4()
{
Container c=getContentPane();
setLayout(null);
JToolBar to= new JToolBar();
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
to.addSeparator();
//to.add(k8);
//to.addSeparator();
k9.addActionListener(this);
to.add(k9);
to.addSeparator();

add(to,BorderLayout.SOUTH);
to.setBounds(0,630,1500,50);
Color j11=new Color(110,211,111,41);
to.setBackground(j11);


JLabel lt=new JLabel("Individual");
JLabel l=new JLabel("Payment for phone no.");
JLabel l1=new JLabel("Enter Account No");
//JLabel l2=new JLabel("Address");
JLabel l3=new JLabel("Payment Mode");
JLabel l13=new JLabel("Invoice Number");
JLabel l4=new JLabel("Payment Detail");
JLabel l5=new JLabel("Demand Draft no.");
JLabel l6=new JLabel("Dated");
JLabel l7=new JLabel("Bill Amount");
JLabel l8=new JLabel("Bill Date");
JLabel l9=new JLabel("Payment Date");
JLabel l11=new JLabel("Branch Name");
ButtonGroup bw1=new ButtonGroup();
c1=new JRadioButton("DD/chk",false);
bw1.add(c1);
 c2=new JRadioButton("Cash",false);
bw1.add(c2);
 t=new JTextField();t.addFocusListener(this);
 t1=new JTextField();t1.addActionListener(this);
// t2=new JTextField();t2.addActionListener(this);
 t3=new JTextField();t3.addActionListener(this);
 t13=new JTextField();t13.addActionListener(this);                 
 t5=new JTextField();t5.addActionListener(this);
 
 t7=new JTextField();t7.addActionListener(this);
 t10=new JTextField();//t.addActionListener(this);
 t9=new JTextField();t9.addActionListener(this);
Font rs=new Font("Vijaya",Font.BOLD,20);
Font rte1=new Font("Aparajita",Font.BOLD,30);
l.setFont(rs);
l1.setFont(rs);
//l2.setFont(rs);
l8.setFont(rs);
l3.setFont(rs);l9.setFont(rs);
l4.setFont(rte1);l13.setFont(rs);
l6.setFont(rs);
l5.setFont(rs);
l7.setFont(rs);
Font rse=new Font("Eras Demi ITC",Font.BOLD,30);
lt.setFont(rse);
lt.setForeground(Color.red);
 x=new JComboBox();
x.addItem("Day");x.addItem("1");x.addItem("2");
x.addItem("3");x.addItem("4");x.addItem("5");
x.addItem("6");x.addItem("7");x.addItem("8");x.addItem("9");
x.addItem("10");x.addItem("11");x.addItem("12");x.addItem("13");
x.addItem("14");x.addItem("15");x.addItem("16");
x.addItem("17");x.addItem("18");x.addItem("19");
x.addItem("20");x.addItem("21");x.addItem("23");
x.addItem("24");x.addItem("25");x.addItem("26");
x.addItem("27");x.addItem("28");x.addItem("29");
x.addItem("30");x.addItem("31");
 m=new JComboBox();
m.addItem("Month");m.addItem("Jan");m.addItem("Feb");
m.addItem("Mar");m.addItem("Jun");m.addItem("Jul");
m.addItem("Aug");m.addItem("Sep");m.addItem("Oct");m.addItem("Nov");
m.addItem("Dec");m.addItem("Oct");m.addItem("nov");m.addItem("Dec");
 m1=new JComboBox();
m1.addItem("Year");m1.addItem("2013");
l.setBounds(90,200,220,50);lt.setBounds(890,200,220,50);
l1.setBounds(90,240,120,50);
//l2.setBounds(90,280,120,50);
l3.setBounds(90,290,120,50);l13.setBounds(90,240,120,50);
l4.setBounds(300,340,220,50);
l5.setBounds(90,380,220,50);l11.setBounds(470,380,120,50);
l6.setBounds(90,430,120,50);
l7.setBounds(90,490,120,50);
l8.setBounds(90,540,120,50);
l9.setBounds(430,540,120,50);
t.setBounds(250,210,300,20);
t1.setBounds(250,250,300,20);
//t2.setBounds(250,290,300,20);
t13.setBounds(250,250,120,20);
t10.setBounds(580,420,200,20);add(t10);
t7.setBounds(590,550,150,20);
t5.setBounds(250,390,200,20);
x.setBounds(250,450,50,30);m.setBounds(330,450,80,30);m1.setBounds(450,450,80,30);
t9.setBounds(250,500,100,30);
c1.setBounds(250,320,70,30);
c2.setBounds(400,320,70,30);
add(l);add(l9);
add(l8);add(l7);
add(l6);add(l5);
add(l4);add(l3);add(t5);
//add(l1);
//add(l2);
add(l13);
add(t);//add(t3);
//add(t1);
//add(t2);
add(t13);
add(x);add(m);add(m1);
add(l11);
add(t7);add(t9);
add(c1);add(lt);
add(c2);l11.setFont(rs);
l.setForeground(Color.blue);
l.setBackground(Color.red);
l1.setForeground(Color.blue);
//l2.setForeground(Color.blue);
l3.setForeground(Color.blue);l13.setForeground(Color.blue);
l4.setForeground(Color.red);
l5.setForeground(Color.blue);
l6.setForeground(Color.blue);
l7.setForeground(Color.blue);
l8.setForeground(Color.blue);
l9.setForeground(Color.blue);l11.setForeground(Color.blue);
 b=new JButton("Submit");
b.setBounds(450,600,90,30);
add(b);
 b1=new JButton("Reset");
b1.setBounds(550,600,90,30);
add(b1);
 b2=new JButton("Cancel");
b2.setBounds(650,600,90,30);
add(b2);
Color j=new Color(100,211,13,14);
c.setBackground(j);

 bd=new JTextField();bd.addActionListener(this);
bd.setBounds(250,560,150,20);
add(bd);

 b1.addActionListener(this);
 b2.addActionListener(this);
Icon i=new ImageIcon("dfas.jpg");
JLabel s1=new JLabel(i);
s1.setBounds(920,240,260,360);
add(s1);

JLabel l110=new JLabel("Bank Name");
 pr1=new JComboBox();
pr1.addItem("SBI");pr1.addItem("HSBC");pr1.addItem("CITY");
pr1.addItem("VIJYA");pr1.addItem("UCO");
pr1.addItem("UNION");pr1.addItem("HDFC");
add(pr1);
pr1.setBounds(480,500,80,30);
l110.setBounds(390,500,80,30);
add(l110);
l110.setFont(rs);
l110.setForeground(Color.blue);

Icon is=new ImageIcon("ban2.jpg");
JLabel e1=new JLabel(is);
e1.setBounds(0,0,1343,186);
add(e1);
b.addActionListener(this);
Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
Date currentTime = localCalendar.getTime();
String currentDay = new Integer(localCalendar.get(Calendar.DATE)).toString();
String currentMonth = new Integer(localCalendar.get(Calendar.MONTH) + 1).toString();
String currentYear = new Integer(localCalendar.get(Calendar.YEAR)).toString();
StringBuffer s89=new StringBuffer();
s89.append(currentDay);
s89.append("/");
s89.append(currentMonth);
s89.append("/");
s89.append(currentYear);
String s45= new String(s89);
t7.setText(s45);
c1.addActionListener(this);
c2.addActionListener(this);
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);k6.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
k8.addActionListener(this);
}
public void focusGained(FocusEvent e)
{
}
public void focusLost(FocusEvent e)
{
Statement x1;
try
{
String s58=t.getText().toString();
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","","");
System.out.println("Connected successfully");
 x1=co.createStatement();
ResultSet y=x1.executeQuery("select amt_af_Tax,date_bill from bill where Telephone_no = '" + s58 +"'");

while(y.next())
{
String w=y.getString(1).toString();
t9.setText(w);
bd.setText(y.getString(2));
}
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
Statement x2;
try
{
int row34=0;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","","");
System.out.println("Connected successfully");
 x2=co.createStatement();
ResultSet y2=x2.executeQuery("select count(*) from subbill");
int d=1152;
while(y2.next())
{
 row34=Integer.parseInt(y2.getString(1));
row34=row34+1;
System.out.print("aB");
}
 d=d+row34;
System.out.println("val=" +d);
String ry=new Integer(d).toString();
t13.setText(ry);

}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}


}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k9)
{
String f1,f2,f3;
f1=t9.getText();
f2=t13.getText();
f3=t7.getText();

 receipt dw1=new receipt(f1,f2,f3);
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
this.dispose();

String fg,fg1,fg2,fg3,fg4;
fg="";
fg1="";
fg2="";
fg3="";
fg4="";
String n=t.getText();
try
{
ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
y1=x.executeQuery("select mob_no,pay_date,invoivce_no,bill_amt from subbill where mob_no= " + n+ "");
System.out.println("k8");
while(y1.next())
{
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
fg=y1.getString(1);
fg1=y1.getString(2);
fg2=y1.getString(3);
fg3=y1.getString(4);
fg4=y1.getString(5);
}
co.close();
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
//x12.setBounds(0,0,1000,1000);
//x12.setVisible(true);
//dispose();
}

if(e.getSource()==k3)
{
regis32 dw1=new regis32();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
 if(e.getSource()==k)
{
sub obj2 = new sub();
obj2.setVisible(true);
obj2.setBounds(0,0,1200,700);
dispose();
}
if(e.getSource()==k1)
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k4)
{
query1 dw1=new query1();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dispose();
}
if(e.getSource()==k2)
{
master dw1=new master();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
if(e.getSource()==k7)
{
aboutus dw1=new aboutus();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
if(e.getSource()==b2)
{
sub dw1=new sub();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);                                                    
dispose();
}
if(e.getSource()==b1)
{
t.setText("");t1.setText("");t3.setText("");t13.setText("");t7.setText("");t10.setText("");t9.setText("");t5.setText("");
}
if(e.getSource()==c2)
{
System.out.println("C1");
t10.setText("");
t10.setEnabled(false);
t5.setText("");
t5.setEnabled(false);

x.setEnabled(false);

m.setEnabled(false);

m1.setEnabled(false);
pr1.setEnabled(false);
}
if(e.getSource()==c1)
{
System.out.println("C2");
t10.setText("");
t10.setEnabled(true);
t5.setText("");
t5.setEnabled(true);
pr1.setEnabled(true);
x.setEnabled(true);

m.setEnabled(true);

m1.setEnabled(true);


}
if(e.getSource()==b)
{
String r,r1,r2,r3,r4,r5,r6,r7;
r=t.getText();
int u=r.length();
//r1=t1.getText();
//int u1=r1.length();        
//r2=t2.getText();
//int u2=r.length();
//r3=t3.getText();
//int u3=r3.length();
//r4=t5.getText();
//int u4=r4.length();
r5=t7.getText();
int u5=r5.length();
r6=t13.getText();
int u6=r6.length();
r7=t9.getText();
int u7=r7.length();
System.out.println(u);
//System.out.println(u3);
//System.out.println(u4);
System.out.println(u5);
System.out.println(u6);
System.out.println(u7);


if(u==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
/*else if(u3==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}*/
/*else if(u4==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}*/
else if(u5==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
else if(u6==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
else if(u7==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}

String str,str1,str2,str3,str4,str5,str6,str7,str8,str9; 
try
{
str=t.getText();
str1=t1.getText();
//str2=t2.getText();
str3=t10.getText();
str4=t7.getText();
str5=t5.getText();
str6=t13.getText();
str7=t9.getText();
str9=bd.getText();
String con1=x.getSelectedItem().toString();
String con2=m.getSelectedItem().toString();
String con3=m1.getSelectedItem().toString();
String con7=pr1.getSelectedItem().toString();


str8=con1+con2+con3;

Boolean r21=c1.isSelected();


System.out.println(r21);
String gen;

if(r21==true)
{
gen="cheque";

}
else 
{
 gen="cash";
}
ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into subbill values(' "+ str +" ','"+ str4 +"', '"+ gen +"', '"+str5+"','"+ str6 +" ', '"+str7+"','"+con7+"','"+str3+"','"+str8+"', '"+str9+"')");
JOptionPane.showMessageDialog(null,"Data is successfully submitted into database.");
System.out.println("inserted records ");
y1=x.executeQuery("select * from subbill");

while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
co.close();
}
catch(ClassNotFoundException ee)
{
JOptionPane.showMessageDialog(null,"Data is not submitted into database.");
System.out.println(ee.toString());
}
catch(SQLException x)
{
JOptionPane.showMessageDialog(null,"Data is not submitted into database.");
System.out.println(x.getMessage());
}




if(e.getSource()==k9)
{
String f1,f2,f3;
f1=t9.getText();
f2=t13.getText();
f3=t7.getText();

 receipt dw1=new receipt(f1,f2,f3);
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
this.dispose();

String fg,fg1,fg2,fg3,fg4;
fg="";
fg1="";
fg2="";
fg3="";
fg4="";
String n=t.getText();
try
{
ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
y1=x.executeQuery("select mob_no,pay_date,invoivce_no,bill_amt from subbill where mob_no= " + n+ "");
System.out.println("k8");
while(y1.next())
{
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
fg=y1.getString(1);
fg1=y1.getString(2);
fg2=y1.getString(3);
fg3=y1.getString(4);
fg4=y1.getString(5);
}
co.close();
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
//x12.setBounds(0,0,1000,1000);
//x12.setVisible(true);
//dispose();
}


}


}


public static void main(String ad[])
{
piz4 dw1=new piz4();
dw1.setBounds(0,0,1200,700);
dw1.setVisible(true);
dw1.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}
