import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
public class piz2 extends JFrame implements ActionListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("TRANSECTION",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
public piz2()
{
Container c=getContentPane();
ButtonGroup br=new ButtonGroup();
setLayout(null);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,600,1500,90);
Color j11=new Color(160,11,111,41);
to.setBackground(j11);



JRadioButton e1=new JRadioButton("PrePaid",true);
add(e1);
br.add(e1);
JRadioButton e2=new JRadioButton("PostPaid",false);
add(e2);
br.add(e2);
JRadioButton e3=new JRadioButton("Local",false);
add(e3);
br.add(e3);
JRadioButton e4=new JRadioButton("STD",false);
add(e4);
br.add(e4);
JRadioButton e5=new JRadioButton("ISD",true);
add(e5);
br.add(e5);
e1.setBounds(200,240,300,40);
e2.setBounds(200,280,300,40);
e3.setBounds(200,320,300,40);
e4.setBounds(200,360,300,40);
e5.setBounds(200,400,300,40);
Icon i=new ImageIcon("ban.jpg");
JLabel e11=new JLabel(i);
e11.setBounds(0,0,1343,186);
add(e11);

Font rte=new Font("Eras Demi ITC",Font.BOLD,20);
e1.setFont(rte);
e2.setFont(rte);
e3.setFont(rte);
e4.setFont(rte);
e5.setFont(rte);
e1.setForeground(Color.red);
e2.setForeground(Color.red);
e3.setForeground(Color.red);
e4.setForeground(Color.red);
e5.setForeground(Color.red);
Font topr=new Font("Forte",Font.BOLD,25);
JLabel rb=new JLabel("BROADBAND");
rb.setBounds(280,210,360,30);
rb.setForeground(Color.blue);
add(rb);
rb.setFont(topr);
Color qw=new Color(150,61,113,14);
c.setBackground(qw);

Icon h=new ImageIcon("confirm.jpg");
JButton b=new JButton(h);
Icon hl=new ImageIcon("cancel.jpg");
JButton b1q=new JButton(hl);
Icon h2=new ImageIcon("reset.jpg");
JButton b2q=new JButton(h2);

b.setBounds(80,500,180,30);
b1q.setBounds(270,500,180,30);
b2q.setBounds(470,500,180,30);
add(b);
add(b1q);
add(b2q);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
login121 obj2 = new login121();
obj2.setVisible(true);
obj2.setSize(1000,600);
}
}
public static void main(String ad[])
{
piz2 dw1=new piz2();
dw1.setBounds(200,200,400,400);
dw1.setVisible(true);
}
}
