import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
public class piz44 extends JFrame implements ActionListener
{
JButton k=new JButton("HOME",new ImageIcon("dfat.jpg"));
JButton k1=new JButton("BILL",new ImageIcon("dfat.jpg"));
JButton k3=new JButton("NEW CONECTION",new ImageIcon("dfat.jpg"));
JButton k4=new JButton("QUERY",new ImageIcon("dfat.jpg"));
JButton k2=new JButton("TRANSECTION",new ImageIcon("dfat.jpg"));
JButton k6=new JButton("DIRECTORY SEARCH",new ImageIcon("dfat.jpg"));
JButton k7=new JButton("ABOUT US",new ImageIcon("dfat.jpg"));
JTextField t,t1,t2,t3,t5,t7,t13,t9,t10;
JComboBox x,m,m1,x1,p,mo,pr1;
JRadioButton c1,c2;
JButton b,b1,b2;
public piz44()
{
Container c=getContentPane();
setLayout(null);
JToolBar to= new JToolBar();
k.addActionListener(this);
k1.addActionListener(this);
k3.addActionListener(this);
k4.addActionListener(this);
k2.addActionListener(this);
k7.addActionListener(this);
to.add(k);
to.addSeparator();
to.add(k2);
to.addSeparator();
to.add(k1);
to.addSeparator();
to.add(k3);
to.addSeparator();
to.add(k4);
to.addSeparator();
to.add(k6);
to.addSeparator();
to.add(k7);
add(to,BorderLayout.SOUTH);
to.setBounds(0,630,1500,50);
Color j11=new Color(110,211,111,41);
to.setBackground(j11);


JLabel lt=new JLabel("Corporate");
JLabel l=new JLabel("Payment for phone no.");
JLabel l1=new JLabel("Enter Account No");
JLabel l2=new JLabel("Address");
JLabel l3=new JLabel("Payment Mode");
JLabel l13=new JLabel("Invoice Number");
JLabel l4=new JLabel("Payment Detail");
JLabel l5=new JLabel("Demand Draft no.");
JLabel l6=new JLabel("Dated");
JLabel l7=new JLabel("Bill Amount");
JLabel l8=new JLabel("Bill Date");
JLabel l9=new JLabel("Payment Date");
JLabel l11=new JLabel("Branch Name");
ButtonGroup bw1=new ButtonGroup();
c1=new JRadioButton("Cheque",false);
bw1.add(c1);
 c2=new JRadioButton("Cash",false);
bw1.add(c2);
 t=new JTextField();
 t1=new JTextField();
 t2=new JTextField();
 t3=new JTextField();
 t13=new JTextField();
 t5=new JTextField();
 
 t7=new JTextField();
 t10=new JTextField();
 t9=new JTextField();
Font rs=new Font("Vijaya",Font.BOLD,20);
Font rte1=new Font("Aparajita",Font.BOLD,30);
l.setFont(rs);
l1.setFont(rs);
l2.setFont(rs);l8.setFont(rs);
l3.setFont(rs);l9.setFont(rs);
l4.setFont(rte1);l13.setFont(rs);
l6.setFont(rs);
l5.setFont(rs);
l7.setFont(rs);
Font rse=new Font("Eras Demi ITC",Font.BOLD,30);
lt.setFont(rse);
lt.setForeground(Color.red);
 x=new JComboBox();
x.addItem("Day");x.addItem("1");x.addItem("2");
x.addItem("3");x.addItem("4");x.addItem("5");
x.addItem("6");x.addItem("7");x.addItem("8");x.addItem("9");
x.addItem("10");x.addItem("11");x.addItem("12");x.addItem("13");
x.addItem("14");x.addItem("15");x.addItem("16");
x.addItem("17");x.addItem("18");x.addItem("19");
x.addItem("20");x.addItem("21");x.addItem("23");
x.addItem("24");x.addItem("25");x.addItem("26");
x.addItem("27");x.addItem("28");x.addItem("29");
x.addItem("30");x.addItem("31");
 m=new JComboBox();
m.addItem("Month");m.addItem("Jan");m.addItem("Feb");
m.addItem("Mar");m.addItem("Jun");m.addItem("Jul");
m.addItem("Aug");m.addItem("Sep");m.addItem("Oct");m.addItem("Nov");
m.addItem("Dec");m.addItem("Oct");m.addItem("nov");m.addItem("Dec");
 m1=new JComboBox();
m1.addItem("Year");m1.addItem("2013");
l.setBounds(90,200,220,50);lt.setBounds(890,200,220,50);
l1.setBounds(90,240,120,50);
l2.setBounds(90,280,120,50);
l3.setBounds(90,330,120,50);l13.setBounds(500,330,120,50);
l4.setBounds(300,370,220,50);
l5.setBounds(90,400,220,50);l11.setBounds(470,400,120,50);
l6.setBounds(90,460,120,50);
l7.setBounds(90,510,120,50);
l8.setBounds(90,550,120,50);
l9.setBounds(90,590,120,50);
t.setBounds(250,210,300,20);
t1.setBounds(250,250,300,20);
t2.setBounds(250,290,300,20);
t13.setBounds(650,330,120,20);
t10.setBounds(580,410,200,20);add(t10);
t7.setBounds(250,600,150,20);
t5.setBounds(250,410,200,20);
x.setBounds(250,470,50,30);m.setBounds(330,470,80,30);m1.setBounds(450,470,80,30);
t9.setBounds(250,520,100,30);
c1.setBounds(250,340,70,30);
c2.setBounds(400,340,70,30);
add(l);add(l9);
add(l8);add(l7);
add(l6);add(l5);
add(l4);add(l3);add(t5);
add(l1);
add(l2);add(l13);
add(t);add(t3);
add(t1);
add(t2);add(t13);
add(x);add(m);add(m1);
add(l11);
add(t7);add(t9);
add(c1);add(lt);
add(c2);l11.setFont(rs);
l.setForeground(Color.blue);
l.setBackground(Color.red);
l1.setForeground(Color.blue);
l2.setForeground(Color.blue);
l3.setForeground(Color.blue);l13.setForeground(Color.blue);
l4.setForeground(Color.red);
l5.setForeground(Color.blue);
l6.setForeground(Color.blue);
l7.setForeground(Color.blue);
l8.setForeground(Color.blue);
l9.setForeground(Color.blue);l11.setForeground(Color.blue);
 b=new JButton("Submit");
b.setBounds(450,600,90,30);
add(b);
 b1=new JButton("Reset");
b1.setBounds(550,600,90,30);
add(b1);
 b2=new JButton("Cancel");
b2.setBounds(650,600,90,30);
add(b2);
Color j=new Color(200,211,113,114);
c.setBackground(j);

 x1=new JComboBox();
x1.addItem("Day");x1.addItem("1");x1.addItem("2");
x1.addItem("3");x1.addItem("4");x1.addItem("5");
x1.addItem("6");x1.addItem("7");x1.addItem("8");x.addItem("9");
x1.addItem("10");x1.addItem("11");x1.addItem("12");x.addItem("13");
x1.addItem("14");x1.addItem("15");x1.addItem("16");
x1.addItem("17");x1.addItem("18");x1.addItem("19");
x1.addItem("20");x1.addItem("21");x1.addItem("23");
x1.addItem("24");x1.addItem("25");x1.addItem("26");
x1.addItem("27");x1.addItem("28");x1.addItem("29");
x1.addItem("30");x1.addItem("31");
 p=new JComboBox();
p.addItem("Month");p.addItem("Jan");p.addItem("Feb");
p.addItem("Mar");p.addItem("Jun");p.addItem("Jul");
p.addItem("Aug");p.addItem("Sep");p.addItem("Oct");p.addItem("Nov");
p.addItem("Dec");p.addItem("Oct");p.addItem("nov");p.addItem("Dec");
 mo=new JComboBox();
mo.addItem("Year");mo.addItem("2013");
x1.setBounds(250,560,50,30);
p.setBounds(330,560,80,30);mo.setBounds(450,560,80,30);
add(x1);add(p);add(mo);
Icon i=new ImageIcon("dfas.jpg");
JLabel s1=new JLabel(i);
s1.setBounds(920,240,260,360);
add(s1);

JLabel l110=new JLabel("Bank Name");
 pr1=new JComboBox();
pr1.addItem("SBI");pr1.addItem("HSBC");pr1.addItem("CITY");
pr1.addItem("VIJYA");pr1.addItem("UCO");
pr1.addItem("UNION");pr1.addItem("HDFC");
add(pr1);
pr1.setBounds(480,515,80,30);
l110.setBounds(390,515,80,30);
add(l110);
l110.setFont(rs);
l110.setForeground(Color.blue);

Icon is=new ImageIcon("ban2.jpg");
JLabel e1=new JLabel(is);
e1.setBounds(0,0,1343,186);
add(e1);
b.addActionListener(this);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==k)
{
login121 obj2 = new login121();
obj2.setVisible(true);
obj2.setSize(1000,600);
}
if(e.getSource()==b)
{
String str,str1,str2,str3,str4,str5,str6,str7,str8,str9; 
try
{
str=t.getText();
str1=t1.getText();
str2=t2.getText();
str3=t10.getText();
str4=t7.getText();
str5=t5.getText();
str6=t13.getText();
str7=t9.getText();
String con1=x.getSelectedItem().toString();
String con2=m.getSelectedItem().toString();
String con3=m1.getSelectedItem().toString();
String con4=x1.getSelectedItem().toString();
String con5=p.getSelectedItem().toString();
String con6=mo.getSelectedItem().toString();
String con7=pr1.getSelectedItem().toString();


str8=con1+con2+con3;
str9=con4+con5+con6;
Boolean r21=c1.isSelected();


System.out.println(r21);
String gen;

if(r21==true)
{
gen="cheque";
}
else 
{
 gen="cash";
}
ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into subbill1 values(' "+ str +" ', '"+ str1 +"','"+ str2 +"','"+ str4 +"', '"+ gen +"', '"+str5+"','"+ str6 +" ', '"+str7+"','"+con7+"','"+str3+"','"+str8+"', '"+str9+"')");
System.out.println("inserted records ");
y1=x.executeQuery("select * from subbill1");

while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
co.close();
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
}
}


public static void main(String ad[])
{
piz44 dw1=new piz44();
dw1.setBounds(300,300,500,500);
dw1.setVisible(true);
}
}
