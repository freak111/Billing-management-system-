import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.io.IOException;
public class logina extends JFrame implements ActionListener
{
JPanel p1,p2;
JLabel l1,l2,l3;
JTextField t1,t2;
JButton b1,b2;
public logina()
{
Container c=getContentPane();
setLayout(null);

l1=new JLabel("USER NAME");
add(l1);
t1=new JTextField(20);
add(t1);
l2=new JLabel("PASSWORD");
add(l2);

t2=new JPasswordField(20);
add(t2);
Icon hl=new ImageIcon("CONA.jpg");   
Icon h=new ImageIcon("RES.jpg");      
b1=new JButton(hl);
add(b1);
b2=new JButton(h);
add(b2);
b2.addActionListener(this);
b1.addActionListener(this);
l1.setBounds(750,250,170,47);
l2.setBounds(750,300,170,47);
     
t1.setBounds(950,250,250,30);
t2.setBounds(950,300,250,30);


b1.setBounds(700,500,170,47);
b2.setBounds(960,500,170,47);
Font f= new Font("Gabriola",Font.BOLD,20);
l1.setFont(f);
l2.setFont(f);
l1.setForeground(Color.red);
l2.setForeground(Color.red);
  
t1.addActionListener(this);
t2.addActionListener(this);

Icon i13=new ImageIcon("dfas.jpg");
JLabel t113=new JLabel(i13);
t113.setBounds(50,305,264,247);
add(t113);
Color yu=new Color(60,160,19,114);
c.setBackground(yu);
Icon i=new ImageIcon("tt copy.jpg");
JLabel t1=new JLabel(i);
t1.setBounds(12,2,1226,160);
add(t1);
}
   
public void actionPerformed(ActionEvent e)
{    
if(e.getSource()==b2)
{
t1.setText("");
t2.setText("");
}
if(e.getSource()==b1)
{
String r,r1;
r=t1.getText();
int u=r.length();
r1=t2.getText();
int p=r1.length();

if(u==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
else if(p==0)
{
JOptionPane.showConfirmDialog((Component)null,"Enter Your Password","Error",JOptionPane.OK_CANCEL_OPTION);  
}
else if(p>8)
{
JOptionPane.showConfirmDialog((Component)null,"Password must be 8 Digit","Error",JOptionPane.OK_CANCEL_OPTION);
}
else
{
String str,str1;
try
{
str=t1.getText();
str1=t2.getText();

ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
x.executeUpdate("insert into lo(u_name,pass) values(' "+ str +" ', '"+ str1 +"' )");
System.out.println("inserted records ");
JOptionPane.showConfirmDialog((Component)null," Login successfull","information",JOptionPane.OK_CANCEL_OPTION);

y1=x.executeQuery("select * from lo");
while(y1.next())
System.out.println(y1.getString(1)+ "\t" + y1.getString(2));
co.close();
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
}
}
sub dw1=new sub();
dw1.setBounds(0,0,1300,700);
dw1.setVisible(true);
dispose();
}


public static void main(String af[])
{
logina dl=new logina();
dl.setVisible(true);
dl.setBounds(0,0,1300,700);
dl.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}

