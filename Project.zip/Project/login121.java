import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import java.sql.*;
import java.io.IOException;
public class login121 extends JFrame implements ActionListener
{
JPanel p1,p2;
JLabel l1,l2,l3,l8;
JTextField t1,t2;
JButton b1,b2;
public login121()
{
Container c=getContentPane();
setLayout(null);

Icon i13=new ImageIcon("dfas.jpg");
JLabel t113=new JLabel(i13);
t113.setBounds(50,305,264,247);
add(t113);

l8=new JLabel("LOGIN");
add(l8);
l1=new JLabel("USER NAME");
add(l1);
t1=new JTextField(20);
add(t1);
l2=new JLabel("PASSWORD");
add(l2);
//l4=new JLabel("MOBILE NUMBER");
//add(l4);
t2=new JPasswordField(20);
add(t2);
Icon hl=new ImageIcon("ram.jpg");   
Icon h=new ImageIcon("untitled.jpg");      
b1=new JButton(hl);
add(b1);
b2=new JButton(h);
add(b2);
b2.addActionListener(this);
l8.setBounds(950,190,180,30);
l1.setBounds(750,250,180,30);
l2.setBounds(750,300,180,30);
   
t1.setBounds(950,250,250,30);
t2.setBounds(950,300,250,30);


b1.setBounds(750,500,210,60);
b2.setBounds(1000,500,230,60);
Font f= new Font("Gabriola",Font.BOLD,20);
l1.setFont(f);
l2.setFont(f);
//l4.setFont(f);
Font tb=new Font("Agency FB",Font.BOLD,30);
l8.setFont(tb);
Icon i3=new ImageIcon("line5.jpg");
JLabel t13=new JLabel(i3);
t13.setBounds(905,210,140,30);
add(t13);
l1.setForeground(Color.red);
l2.setForeground(Color.red);

l8.setForeground(Color.red);  
t1.addActionListener(this);
t2.addActionListener(this);
b1.addActionListener(this);
Color yu=new Color(60,160,19,114);
c.setBackground(yu);
Icon i4=new ImageIcon("ban4.jpg");
JLabel e14=new JLabel(i4);
e14.setBounds(0,0,1343,186);
add(e14);
}
   
public void actionPerformed(ActionEvent e)
{    
if(e.getSource()==b2)
{
logina dw1=new logina();
dw1.setBounds(0,0,1300,700);
dw1.setVisible(true);
dispose();

}
if(e.getSource()==b1)
{
String r,r1;
r=t1.getText();
int u=r.length();
r1=t2.getText();
int p=r1.length();
if(u==0)
{
int x=JOptionPane.showConfirmDialog((Component)null,"Cannot be left blank","Error",JOptionPane.OK_CANCEL_OPTION);
}
else if(p==0)
{
JOptionPane.showConfirmDialog((Component)null,"Enter Your Password","Error",JOptionPane.OK_CANCEL_OPTION);  
}


else
{
String str,str1;
try
{
int row=0;
str=t1.getText();
str1=t2.getText();

ResultSet y1;
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection co= DriverManager.getConnection("jdbc:odbc:manish","manish","");
System.out.println("Connected successfully");
Statement x=co.createStatement();
y1=x.executeQuery("select * from lo where u_name ='" + str +"' and pass='"+str1+ "'");
System.out.println("log");
while(y1.next())
{
row=row+1;
System.out.println(y1.getString(1)+ "\t" + y1.getString(2)+ "\t" );
}
if(row!=1)
{
JOptionPane.showConfirmDialog((Component)null," Login successfull","information",JOptionPane.OK_CANCEL_OPTION);
sub dw1=new sub();
dw1.setBounds(0,0,1300,700);
dw1.setVisible(true);
dispose();
}
else
{
JOptionPane.showConfirmDialog((Component)null,"Invalid login","Error",JOptionPane.OK_CANCEL_OPTION);
}
co.close();
}
catch(ClassNotFoundException ee)
{
System.out.println(ee.toString());
}
catch(SQLException x)
{
System.out.println(x.getMessage());
}
}


}
}
public static void main(String af[])
{
login121 dl=new login121();
dl.setVisible(true);
dl.setBounds(0,0,1300,700);
dl.setDefaultCloseOperation(EXIT_ON_CLOSE);
}
}

